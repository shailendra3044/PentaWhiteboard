import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { useUser, UserButton } from '@clerk/clerk-react'
import { supabase } from '../lib/supabase'
import { jsPDF } from 'jspdf'
import {
    Plus, MoreVertical, FileText,
    Search, Clock, Trash2, Edit2, Pencil, X,
    FileUp, FileType, Maximize2, ExternalLink,
    Download, CloudOff, Cloud
} from 'lucide-react'

export default function Dashboard() {
    const navigate = useNavigate()
    const { user } = useUser()
    const [boards, setBoards] = useState([])
    const [isLoading, setIsLoading] = useState(true)
    const [searchTerm, setSearchTerm] = useState('')
    const [showCreateModal, setShowCreateModal] = useState(false)
    const [newBoardTitle, setNewBoardTitle] = useState('')
    const [isUploadingPdf, setIsUploadingPdf] = useState(false)
    const pdfInputRef = useRef(null)
    const pdfJs = useRef(null)

    // Load PDF.js
    useEffect(() => {
        const script = document.createElement('script')
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js'
        script.onload = () => {
            pdfJs.current = window['pdfjs-dist/build/pdf']
            pdfJs.current.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js'
        }
        document.head.appendChild(script)
    }, [])

    // Sync user data to Supabase and Fetch Boards
    useEffect(() => {
        const initializeDashboard = async () => {
            if (!user) return

            // 1. Sync User
            const userData = {
                clerk_id: user.id,
                name: user.fullName || user.username || 'Anonymous',
                email: user.primaryEmailAddress?.emailAddress,
                created_at: new Date().toISOString()
            }
            await supabase.from('users').upsert(userData, { onConflict: 'clerk_id' })

            // 2. Fetch User's Boards
            fetchBoards()
        }

        initializeDashboard()
    }, [user])

    const fetchBoards = async () => {
        setIsLoading(true)
        
        // 1. Fetch Local Boards
        const localData = JSON.parse(localStorage.getItem('penta_local_boards') || '[]')
        
        // 2. Fetch Cloud Boards
        let cloudData = []
        if (user) {
            const { data, error } = await supabase
                .from('boards')
                .select('*')
                .eq('user_id', user.id)
                .order('last_edited', { ascending: false })
            if (data) cloudData = data
            if (error) console.error('Error fetching cloud boards:', error)
        }

        // 3. Merge (preserving local-only items)
        const combined = [...localData.map(b => ({ ...b, isLocal: true })), ...cloudData.map(b => ({ ...b, isLocal: false }))]
        setBoards(combined.sort((a,b) => new Date(b.last_edited) - new Date(a.last_edited)))
        setIsLoading(false)
    }

    const saveToLocal = (board) => {
        const local = JSON.parse(localStorage.getItem('penta_local_boards') || '[]')
        const updated = [board, ...local]
        localStorage.setItem('penta_local_boards', JSON.stringify(updated))
        fetchBoards()
    }

    const handleSyncToCloud = async (board) => {
        if (!user) return alert('Please sign in to sync to cloud')
        
        const { data, error } = await supabase
            .from('boards')
            .insert({
                user_id: user.id,
                title: board.title,
                content: board.content,
                type: board.type,
                preview_color: board.preview_color
            })
            .select()
            .single()

        if (data) {
            // Remove from local and refresh
            const local = JSON.parse(localStorage.getItem('penta_local_boards') || '[]')
            localStorage.setItem('penta_local_boards', JSON.stringify(local.filter(b => b.id !== board.id)))
            fetchBoards()
        } else if (error) {
            console.error('Sync error:', error)
            alert('Failed to sync: ' + error.message)
        }
    }

    const handleCreateBoard = async (e) => {
        e.preventDefault()
        if (!newBoardTitle.trim()) return

        const newBoard = {
            id: 'local-' + Date.now(),
            title: newBoardTitle.trim(),
            content: [],
            type: 'whiteboard',
            preview_color: ['#818cf8', '#f87171', '#fb923c', '#34d399', '#c084fc'][Math.floor(Math.random() * 5)],
            last_edited: new Date().toISOString(),
            isLocal: true
        }

        saveToLocal(newBoard)
        setShowCreateModal(false)
        navigate(`/board/${newBoard.id}`)
    }

    const handlePdfUpload = async (e) => {
        const file = e.target.files?.[0]
        if (!file || !pdfJs.current || !user) return

        setIsUploadingPdf(true)
        try {
            const arrayBuffer = await file.arrayBuffer()
            const pdf = await pdfJs.current.getDocument(arrayBuffer).promise
            const pages = []
            
            // Increased limit to 30 pages and reduced scale for better performance/size
            const numPages = Math.min(pdf.numPages, 30)
            
            for (let i = 1; i <= numPages; i++) {
                const pg = await pdf.getPage(i)
                const vp = pg.getViewport({ scale: 1.2 }) // Reduced from 1.5
                const canvas = document.createElement('canvas')
                canvas.width = vp.width
                canvas.height = vp.height
                await pg.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise
                pages.push({ 
                    src: canvas.toDataURL('image/jpeg', 0.6), // Reduced from 0.8 to significantly save space
                    width: vp.width, 
                    height: vp.height 
                })
            }

            const newBoard = {
                id: 'local-' + Date.now(),
                title: file.name.replace('.pdf', ''),
                content: { pages, annotations: {} },
                type: 'pdf',
                preview_color: '#f87171',
                last_edited: new Date().toISOString(),
                isLocal: true
            }

            saveToLocal(newBoard)
            navigate(`/pdf-board/${newBoard.id}`)
        } catch (error) {
            console.error('Full PDF Error Context:', error)
            alert(`Error processing PDF: ${error.message || 'Unknown error'}`)
        } finally {
            setIsUploadingPdf(false)
        }
    }

    const deleteBoard = async (id, isLocal) => {
        if (isLocal) {
            const local = JSON.parse(localStorage.getItem('penta_local_boards') || '[]')
            localStorage.setItem('penta_local_boards', JSON.stringify(local.filter(b => b.id !== id)))
            fetchBoards()
        } else {
            const { error } = await supabase.from('boards').delete().eq('id', id)
            if (!error) fetchBoards()
            else console.error('Error deleting board:', error)
        }
    }

    const downloadUpdatedPdf = async (board) => {
        if (!board.content?.pages) return
        
        const firstPage = board.content.pages[0]
        const firstOrientation = firstPage.width > firstPage.height ? 'l' : 'p'
        
        const doc = new jsPDF({
            orientation: firstOrientation,
            unit: 'px',
            format: [firstPage.width, firstPage.height]
        })

        const drawStroke = (ctx, pts, color, width, opacity = 1) => {
            if (!pts || pts.length < 2) return
            ctx.save()
            ctx.globalAlpha = opacity
            ctx.strokeStyle = color
            ctx.lineWidth = width
            ctx.lineCap = 'round'
            ctx.lineJoin = 'round'
            ctx.beginPath()
            ctx.moveTo(pts[0].x, pts[0].y)
            for (let i = 1; i < pts.length - 1; i++) {
                const mx = (pts[i].x + pts[i + 1].x) / 2
                const my = (pts[i].y + pts[i + 1].y) / 2
                ctx.quadraticCurveTo(pts[i].x, pts[i].y, mx, my)
            }
            ctx.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y)
            ctx.stroke()
            ctx.restore()
        }

        const pages = board.content.pages
        const annotations = board.content.annotations || {}

        for (let i = 0; i < pages.length; i++) {
            const page = pages[i]
            const orientation = page.width > page.height ? 'l' : 'p'
            
            if (i > 0) {
                doc.addPage([page.width, page.height], orientation)
            } else {
                // Adjust first page orientation/size if necessary
                // (though jsPDF handles the first page in the constructor)
            }

            const canvas = document.createElement('canvas')
            canvas.width = page.width
            canvas.height = page.height
            const ctx = canvas.getContext('2d')

            // Ensure white background for PDF
            ctx.fillStyle = '#ffffff'
            ctx.fillRect(0, 0, canvas.width, canvas.height)

            // Draw original page
            const img = new Image()
            img.src = page.src
            await new Promise((resolve) => {
                img.onload = () => {
                    ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
                    resolve()
                }
                img.onerror = resolve
            })

            // Draw annotations for this page
            const strokes = annotations[i] || []
            strokes.forEach(s => drawStroke(ctx, s.pts, s.color, s.size, s.opacity))

            const pageData = canvas.toDataURL('image/jpeg', 0.95)
            doc.addImage(pageData, 'JPEG', 0, 0, page.width, page.height)
        }

        doc.save(`${board.title}_updated.pdf`)
    }

    const filteredBoards = boards.filter(b =>
        b.title.toLowerCase().includes(searchTerm.toLowerCase()) && (b.type !== 'pdf')
    )

    const pdfBoards = boards.filter(b =>
        b.title.toLowerCase().includes(searchTerm.toLowerCase()) && (b.type === 'pdf')
    )

    return (
        <div className="min-h-screen bg-[#030712] text-white">
            {/* ── Header ── */}
            <header className="h-16 border-b border-white/5 bg-gray-950/50 backdrop-blur-md px-6 flex items-center justify-between sticky top-0 z-50">
                <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center shadow-lg shadow-violet-500/20">
                        <Pencil className="w-4 h-4 text-white" />
                    </div>
                    <span className="font-bold tracking-tight text-lg">Penta <span className="text-violet-500">Whiteboard</span></span>
                </div>

                <div className="flex items-center gap-4">
                    <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-full border border-white/10">
                        <span className="text-sm font-medium text-gray-300">
                            {user?.fullName || user?.username || 'Welcome'}
                        </span>
                    </div>
                    <UserButton afterSignOutUrl="/" />
                </div>
            </header>

            <main className="max-w-7xl mx-auto px-6 py-10 space-y-12">
                {/* ── Dashboard Top Bar ── */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="space-y-1">
                        <h1 className="text-4xl font-black tracking-tight">Dashboard</h1>
                        <p className="text-gray-500 text-sm">Manage your whiteboards and PDF documents.</p>
                    </div>

                    <div className="flex items-center gap-3">
                        <div className="relative group">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 group-focus-within:text-violet-400 transition-colors" />
                            <input
                                type="text"
                                placeholder="Search everything..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-sm outline-none focus:ring-2 ring-violet-500/20 focus:border-violet-500/40 min-w-[240px] transition-all"
                            />
                        </div>
                        <button
                            onClick={() => setShowCreateModal(true)}
                            className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white px-5 py-2.5 rounded-xl font-bold transition-all shadow-xl shadow-violet-600/20 active:scale-95 whitespace-nowrap"
                        >
                            <Plus className="w-5 h-5" />
                            New Board
                        </button>
                    </div>
                </div>

                <div className="space-y-8">
                    {/* ── Whiteboards Section ── */}
                    <section className="space-y-6">
                        <div className="flex items-center gap-2">
                            <div className="p-2 bg-violet-500/10 rounded-lg">
                                <FileText className="w-5 h-5 text-violet-400" />
                            </div>
                            <h2 className="text-xl font-bold">My Whiteboards</h2>
                        </div>

                        {isLoading ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                                {[1, 2, 3, 4].map(i => (
                                    <div key={i} className="aspect-video bg-white/5 rounded-2xl animate-pulse" />
                                ))}
                            </div>
                        ) : filteredBoards.length > 0 ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                                {filteredBoards.map(board => (
                                    <BoardCard 
                                        key={board.id} 
                                        board={board} 
                                        navigate={navigate} 
                                        deleteBoard={() => deleteBoard(board.id, board.isLocal)} 
                                        syncToCloud={() => handleSyncToCloud(board)}
                                    />
                                ))}
                            </div>
                        ) : (
                            <EmptyState icon={FileText} text="No whiteboards yet" />
                        )}
                    </section>

                    {/* ── PDFs Section ── */}
                    <section className="space-y-6 pt-4">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <div className="p-2 bg-red-500/10 rounded-lg">
                                    <FileType className="w-5 h-5 text-red-400" />
                                </div>
                                <h2 className="text-xl font-bold">My PDFs</h2>
                            </div>
                            <button
                                onClick={() => pdfInputRef.current?.click()}
                                disabled={isUploadingPdf}
                                className="flex items-center gap-2 bg-white/5 hover:bg-white/10 text-white px-4 py-2 rounded-xl text-sm font-bold border border-white/10 transition-all disabled:opacity-50"
                            >
                                {isUploadingPdf ? (
                                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                ) : <FileUp className="w-4 h-4" />}
                                {isUploadingPdf ? 'Processing...' : 'Upload PDF'}
                            </button>
                            <input
                                ref={pdfInputRef}
                                type="file"
                                accept=".pdf"
                                className="hidden"
                                onChange={handlePdfUpload}
                            />
                        </div>

                        {isLoading ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                                {[1, 2, 3, 4].map(i => (
                                    <div key={i} className="aspect-video bg-white/5 rounded-2xl animate-pulse" />
                                ))}
                            </div>
                        ) : pdfBoards.length > 0 ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                                {pdfBoards.map(board => (
                                    <PdfCard 
                                        key={board.id} 
                                        board={board} 
                                        navigate={navigate} 
                                        deleteBoard={() => deleteBoard(board.id, board.isLocal)} 
                                        downloadPdf={() => downloadUpdatedPdf(board)}
                                        syncToCloud={() => handleSyncToCloud(board)}
                                    />
                                ))}
                            </div>
                        ) : (
                            <EmptyState 
                                icon={FileType} 
                                text="No PDF documents yet" 
                                subtext="Upload a PDF to start annotating and teaching."
                                action={() => pdfInputRef.current?.click()}
                                actionText="Upload your first PDF"
                            />
                        )}
                    </section>
                </div>
            </main>

            {/* ── Create Board Modal ── */}
            {showCreateModal && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowCreateModal(false)} />
                    <form
                        onSubmit={handleCreateBoard}
                        className="relative w-full max-w-md bg-gray-900 border border-white/10 rounded-[2.5rem] p-8 shadow-3xl animate-reveal"
                    >
                        <button
                            type="button"
                            onClick={() => setShowCreateModal(false)}
                            className="absolute top-6 right-6 p-2 text-gray-500 hover:text-white hover:bg-white/5 rounded-full transition-all"
                        >
                            <X className="w-5 h-5" />
                        </button>

                        <div className="space-y-6">
                            <div className="space-y-2 text-center">
                                <div className="w-14 h-14 bg-violet-600/20 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-violet-500/20">
                                    <Plus className="w-7 h-7 text-violet-500" />
                                </div>
                                <h2 className="text-2xl font-bold">Create New Board</h2>
                                <p className="text-gray-400 text-sm">Give your masterpiece a name to get started.</p>
                            </div>

                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest pl-1">Board Title</label>
                                    <input
                                        autoFocus
                                        type="text"
                                        placeholder="e.g. My Awesome Project"
                                        value={newBoardTitle}
                                        onChange={(e) => setNewBoardTitle(e.target.value)}
                                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white outline-none focus:ring-2 ring-violet-500/20 focus:border-violet-500/40 transition-all"
                                    />
                                </div>

                                <button
                                    type="submit"
                                    disabled={!newBoardTitle.trim()}
                                    className="w-full bg-violet-600 hover:bg-violet-500 disabled:opacity-50 disabled:cursor-not-allowed text-white py-4 rounded-2xl font-bold text-lg transition-all shadow-xl shadow-violet-600/20 active:scale-95 flex items-center justify-center gap-2"
                                >
                                    Start Creating <Pencil className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            )}
        </div>
    )
}

function BoardCard({ board, navigate, deleteBoard, syncToCloud }) {
    return (
        <div className="group relative bg-gray-900/40 border border-white/5 rounded-2xl overflow-hidden hover:border-violet-500/30 transition-all hover:shadow-2xl hover:shadow-violet-600/5 flex flex-col">
            <div
                onClick={() => navigate(`/board/${board.id}`)}
                className="aspect-video w-full relative cursor-pointer overflow-hidden bg-gray-800"
            >
                <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
                <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute inset-0 flex items-center justify-center">
                    <FileText className="w-12 h-12 text-white/5 group-hover:scale-110 group-hover:text-white/10 transition-all duration-500" />
                </div>
                
                <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-0.5 bg-black/40 backdrop-blur-md rounded text-[10px] font-bold text-white border border-white/5">
                    {board.isLocal ? <CloudOff className="w-3 h-3 text-gray-400" /> : <Cloud className="w-3 h-3 text-violet-400" />}
                    {board.isLocal ? 'LOCAL' : 'CLOUD'}
                </div>

                <div className="absolute top-3 right-3 w-2 h-2 rounded-full shadow-[0_0_8px]" style={{ backgroundColor: board.preview_color, boxShadow: `0 0 8px ${board.preview_color}` }} />
            </div>

            <div className="p-4 flex flex-col gap-3 border-t border-white/5">
                <div className="flex items-center justify-between gap-2">
                    <div className="flex flex-col min-w-0">
                        <h3 className="font-bold text-gray-200 truncate group-hover:text-white transition-colors text-sm">
                            {board.title}
                        </h3>
                        <div className="flex items-center gap-1.5 text-[10px] text-gray-500">
                            <Clock className="w-3 h-3" />
                            {new Date(board.last_edited).toLocaleDateString()}
                        </div>
                    </div>
                    <div className="flex items-center gap-1">
                        {board.isLocal && (
                            <button 
                                onClick={(e) => { e.stopPropagation(); syncToCloud(); }}
                                className="p-2 text-gray-500 hover:text-violet-400 hover:bg-violet-500/10 rounded-lg transition-all"
                                title="Sync to Cloud"
                            >
                                <Cloud className="w-4 h-4" />
                            </button>
                        )}
                        <button 
                            onClick={(e) => { e.stopPropagation(); deleteBoard(); }}
                            className="p-2 text-gray-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all"
                            title="Delete Board"
                        >
                            <Trash2 className="w-4 h-4" />
                        </button>
                        <button 
                            onClick={() => navigate(`/board/${board.id}`)}
                            className="p-2 text-gray-500 hover:text-violet-400 hover:bg-violet-500/10 rounded-lg transition-all"
                            title="Open Board"
                        >
                            <Edit2 className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}

function PdfCard({ board, navigate, deleteBoard, downloadPdf, syncToCloud }) {
    const [isDownloading, setIsDownloading] = useState(false)

    const handleDownload = async (e) => {
        e.stopPropagation()
        setIsDownloading(true)
        try {
            await downloadPdf()
        } catch (err) {
            console.error('Download error:', err)
        } finally {
            setIsDownloading(false)
        }
    }

    return (
        <div className="group relative bg-gray-900/40 border border-white/5 rounded-2xl overflow-hidden hover:border-red-500/30 transition-all hover:shadow-2xl hover:shadow-red-600/5 flex flex-col">
            <div
                onClick={() => navigate(`/pdf-board/${board.id}`)}
                className="aspect-video w-full relative cursor-pointer overflow-hidden bg-red-950/20"
            >
                <div className="absolute inset-0 opacity-20 flex items-center justify-center p-8">
                    {board.content?.pages?.[0]?.src ? (
                        <img src={board.content.pages[0].src} className="w-full h-full object-contain object-top rounded-sm shadow-lg group-hover:scale-105 transition-transform duration-500" />
                    ) : <FileType className="w-12 h-12 text-red-500/20" />}
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60" />
                
                <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-0.5 bg-black/40 backdrop-blur-md rounded text-[10px] font-bold text-white border border-white/10">
                    <FileType className="w-3 h-3" /> PDF
                    <div className="w-px h-2 bg-white/20 mx-1" />
                    {board.isLocal ? <CloudOff className="w-3 h-3 text-gray-400" /> : <Cloud className="w-3 h-3 text-red-400" />}
                    {board.isLocal ? 'LOCAL' : 'CLOUD'}
                </div>

                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="bg-red-600 text-white p-3 rounded-full shadow-2xl scale-75 group-hover:scale-100 transition-transform">
                        <Maximize2 className="w-6 h-6" />
                    </div>
                </div>
            </div>

            <div className="p-4 flex flex-col gap-3 border-t border-white/5">
                <div className="flex items-center justify-between gap-2">
                    <div className="flex flex-col min-w-0">
                        <h3 className="font-bold text-gray-200 truncate group-hover:text-white transition-colors text-sm">
                            {board.title}
                        </h3>
                        <div className="flex items-center gap-1.5 text-[10px] text-gray-500">
                            <FileType className="w-3 h-3" />
                            {board.content?.pages?.length || 0} Pages
                        </div>
                    </div>
                    <div className="flex items-center gap-1">
                        {board.isLocal && (
                            <button 
                                onClick={(e) => { e.stopPropagation(); syncToCloud(); }}
                                className="p-2 text-gray-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all"
                                title="Sync to Cloud"
                            >
                                <Cloud className="w-4 h-4" />
                            </button>
                        )}
                        <button 
                            disabled={isDownloading}
                            onClick={handleDownload}
                            className="p-2 text-gray-500 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-all disabled:opacity-50"
                            title="Download Updated PDF"
                        >
                            {isDownloading ? (
                                <div className="w-4 h-4 border-2 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin" />
                            ) : <Download className="w-4 h-4" />}
                        </button>
                        <button 
                            onClick={(e) => { e.stopPropagation(); deleteBoard(); }}
                            className="p-2 text-gray-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all"
                            title="Delete PDF"
                        >
                            <Trash2 className="w-4 h-4" />
                        </button>
                        <button 
                            onClick={() => navigate(`/pdf-board/${board.id}`)}
                            className="p-2 text-gray-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all"
                            title="Fullscreen"
                        >
                            <Maximize2 className="w-4 h-4" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}

function EmptyState({ icon: Icon, text, subtext, action, actionText }) {
    return (
        <div className="flex flex-col items-center justify-center py-16 px-4 bg-gray-900/20 border border-dashed border-white/10 rounded-3xl space-y-4 text-center">
            <div className="p-4 bg-white/5 rounded-2xl">
                <Icon className="w-8 h-8 text-gray-600" />
            </div>
            <div className="space-y-1">
                <h3 className="font-bold text-gray-400">{text}</h3>
                {subtext && <p className="text-gray-500 text-xs max-w-xs">{subtext}</p>}
            </div>
            {action && (
                <button
                    onClick={action}
                    className="text-white bg-white/5 hover:bg-white/10 px-4 py-2 rounded-xl text-xs font-bold border border-white/10 transition-all"
                >
                    {actionText}
                </button>
            )}
        </div>
    )
}
