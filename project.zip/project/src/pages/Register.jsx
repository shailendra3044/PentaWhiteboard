import { SignUp } from "@clerk/clerk-react"
import { Pencil } from "lucide-react"

export default function RegisterPage() {
    return (
        <div className="min-h-screen bg-[#030712] flex flex-col items-center justify-center p-6 relative overflow-hidden text-white">
            {/* Background Orbs */}
            <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-violet-600/10 rounded-full blur-[120px]" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-600/10 rounded-full blur-[120px]" />

            <div className="z-10 w-full max-w-md space-y-8 flex flex-col items-center">
                <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-violet-600 rounded-xl flex items-center justify-center shadow-lg shadow-violet-500/20">
                        <Pencil className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-2xl font-bold tracking-tight">Penta <span className="text-violet-500">Auth</span></span>
                </div>

                <SignUp
                    appearance={{
                        elements: {
                            formButtonPrimary: "bg-violet-600 hover:bg-violet-500 text-sm normal-case",
                            card: "bg-gray-900/50 border border-white/10 backdrop-blur-xl shadow-2xl",
                            headerTitle: "text-white",
                            headerSubtitle: "text-gray-400",
                            socialButtonsBlockButton: "bg-white/5 border-white/10 text-white hover:bg-white/10",
                            dividerLine: "bg-white/10",
                            dividerText: "text-gray-500",
                            formFieldLabel: "text-gray-300",
                            formFieldInput: "bg-white/5 border-white/10 text-white focus:ring-violet-500",
                            footerActionText: "text-gray-400",
                            footerActionLink: "text-violet-400 hover:text-violet-300"
                        }
                    }}
                    signInUrl="/login"
                    forceRedirectUrl="/dashboard"
                />
            </div>
        </div>
    )
}
