import { useState, useRef, useEffect, useCallback } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import {
    Pencil, Highlighter, Eraser, Undo2, Redo2,
    ChevronLeft, ChevronRight, Maximize, X,
    ArrowLeft, Save, MousePointer2, GripVertical,
    Download, Layout
} from 'lucide-react'

const COLORS = [
    '#ffffff', '#f87171', '#fb923c', '#fbbf24', '#4ade80',
    '#22d3ee', '#60a5fa', '#a78bfa', '#f472b6', '#94a3b8',
]

export default function PdfBoard() {
    const { id: boardId } = useParams()
    const [title, setTitle] = useState('Loading...')
    const [pages, setPages] = useState([])
    const [slideIdx, setSlideIdx] = useState(0)
    const [tool, setTool] = useState('pen')
    const [color, setColor] = useState('#f87171')
    const [penSize, setPenSize] = useState(4)
    const [annotations, setAnnotations] = useState({}) // { slideIdx: strokes[] }
    const [isSaving, setIsSaving] = useState(false)
    const [showUI, setShowUI] = useState(true)

    const canvasRef = useRef(null)
    const containerRef = useRef(null)
    const curStroke = useRef(null)
    const [pageImage, setPageImage] = useState(null) // State for current page image

    // Pre-load current page image for smooth drawing
    useEffect(() => {
        if (!pages[slideIdx]) return
        
        const img = new Image()
        img.src = pages[slideIdx].src
        img.onload = () => {
            // Set canvas size ONLY once when image loads
            const c = canvasRef.current
            if (c) {
                c.width = img.width
                c.height = img.height
            }
            setPageImage(img)
        }
        img.onerror = (err) => {
            console.error("Failed to load PDF page image source", err)
        }
    }, [slideIdx, pages])

    // Load PDF data (Offline-First)
    useEffect(() => {
        const loadPdf = async () => {
            if (!boardId) return

            // 1. Try Local Hub first
            const localBoards = JSON.parse(localStorage.getItem('penta_local_boards') || '[]')
            const localMatch = localBoards.find(b => b.id === boardId)
            
            if (localMatch) {
                setTitle(localMatch.title)
                if (localMatch.content?.pages) {
                    setPages(localMatch.content.pages)
                    setAnnotations(localMatch.content.annotations || {})
                }
                return
            }

            // 2. Try Cache for Cloud Boards
            const cache = JSON.parse(localStorage.getItem('penta_cloud_cache') || '{}')
            if (cache[boardId]) {
                const cached = cache[boardId]
                setTitle(cached.title)
                if (cached.content?.pages) {
                    setPages(cached.content.pages)
                    setAnnotations(cached.content.annotations || {})
                }
            }

            // 3. Fetch from Supabase
            const { data, error } = await supabase
                .from('boards')
                .select('*')
                .eq('id', boardId)
                .single()

            if (data && data.type === 'pdf') {
                setTitle(data.title)
                if (data.content?.pages) {
                    setPages(data.content.pages)
                    setAnnotations(data.content.annotations || {})

                    // Update Cache
                    const newCache = { ...JSON.parse(localStorage.getItem('penta_cloud_cache') || '{}'), [boardId]: data }
                    localStorage.setItem('penta_cloud_cache', JSON.stringify(newCache))
                }
            } else if (error && !cache[boardId]) {
                console.error('Error loading PDF:', error)
                setTitle('Error')
            }
        }
        loadPdf()
    }, [boardId])

    // ─── Save PDF Board Logic (Offline-First) ───
    const handleSave = async () => {
        if (!boardId || isSaving) return
        setIsSaving(true)

        // 1. Handle Local-Only Boards
        if (boardId.toString().startsWith('local-')) {
            const local = JSON.parse(localStorage.getItem('penta_local_boards') || '[]')
            const updated = local.map(b => b.id === boardId ? { 
                ...b, 
                content: { ...b.content, annotations }, 
                last_edited: new Date().toISOString() 
            } : b)
            localStorage.setItem('penta_local_boards', JSON.stringify(updated))
            setIsSaving(false)
            showSaveFeedback()
            return
        }

        // 2. Handle Cloud Boards
        // Update Cache First
        const cache = JSON.parse(localStorage.getItem('penta_cloud_cache') || '{}')
        if (cache[boardId]) {
            cache[boardId].content.annotations = annotations
            cache[boardId].last_edited = new Date().toISOString()
            localStorage.setItem('penta_cloud_cache', JSON.stringify(cache))
        }

        const { error } = await supabase
            .from('boards')
            .update({
                content: { pages, annotations },
                last_edited: new Date().toISOString()
            })
            .eq('id', boardId)

        if (error) console.warn('Network error, saved to local cache only.', error)
        
        setIsSaving(false)
        showSaveFeedback()
    }

    const showSaveFeedback = () => {
        const feedback = document.getElementById('save-feedback')
        if (feedback) {
            feedback.classList.remove('opacity-0')
            setTimeout(() => feedback.classList.add('opacity-0'), 2000)
        }
    }

    // Auto-sync background listener
    useEffect(() => {
        const sync = () => { if (navigator.onLine) handleSave() }
        window.addEventListener('online', sync)
        return () => window.removeEventListener('online', sync)
    }, [annotations])

    const draw = useCallback(() => {
        const c = canvasRef.current
        if (!c || !pageImage) return
        const ctx = c.getContext('2d')
        
        // Ensure white background
        ctx.fillStyle = '#ffffff'
        ctx.fillRect(0, 0, c.width, c.height)
        
        // Draw image with error handling
        try {
            ctx.drawImage(pageImage, 0, 0)
        } catch (e) {
            console.warn("DrawImage attempted on stale image", e)
        }
        
        // Draw stored annotations
        const strokes = annotations[slideIdx] || []
        strokes.forEach(s => drawStroke(ctx, s.pts, s.color, s.size, s.opacity))
        
        // Draw current stroke
        if (curStroke.current) {
            drawStroke(ctx, curStroke.current.pts, curStroke.current.color, curStroke.current.size, curStroke.current.opacity)
        }
    }, [slideIdx, annotations, pageImage])

    useEffect(() => { draw() }, [draw])

    function drawStroke(ctx, pts, color, width, opacity = 1) {
        if (!pts || pts.length < 2) return
        ctx.save()
        ctx.globalAlpha = opacity
        ctx.strokeStyle = color
        ctx.lineWidth = width
        ctx.lineCap = 'round'
        ctx.lineJoin = 'round'
        ctx.beginPath()
        ctx.moveTo(pts[0].x, pts[0].y)
        for (let i = 1; i < pts.length - 1; i++) {
            const mx = (pts[i].x + pts[i + 1].x) / 2
            const my = (pts[i].y + pts[i + 1].y) / 2
            ctx.quadraticCurveTo(pts[i].x, pts[i].y, mx, my)
        }
        ctx.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y)
        ctx.stroke()
        ctx.restore()
    }

    const onPointerDown = (e) => {
        const c = canvasRef.current
        if (!c || !pageImage) return
        
        // Lock the pointer to the canvas for stable interaction
        try { c.setPointerCapture(e.pointerId) } catch (err) {}
        
        const r = c.getBoundingClientRect()
        if (r.width === 0 || r.height === 0) return // Skip if layout is not ready
        
        const scaleX = c.width / r.width
        const scaleY = c.height / r.height
        const x = (e.clientX - r.left) * scaleX
        const y = (e.clientY - r.top) * scaleY
        
        // Prevent default browser behaviors (scrolling/selection) during drawing
        if (e.cancelable) e.preventDefault()

        if (tool === 'eraser') {
            const strokes = annotations[slideIdx] || []
            const filtered = strokes.filter(s => {
                const eraserSize = 25 * scaleX
                return !s.pts.some(p => Math.hypot(p.x - x, p.y - y) < eraserSize)
            })
            setAnnotations(a => ({ ...a, [slideIdx]: filtered }))
            return
        }

        curStroke.current = { 
            pts: [{ x, y }], 
            color, 
            size: tool === 'highlighter' ? penSize * 4 : penSize, 
            opacity: tool === 'highlighter' ? 0.35 : 1 
        }
        
        // Initial draw for the first point
        draw()
    }

    const onPointerMove = (e) => {
        if (!curStroke.current || !canvasRef.current) return
        
        const c = canvasRef.current
        const r = c.getBoundingClientRect()
        if (r.width === 0) return

        const x = (e.clientX - r.left) * (c.width / r.width)
        const y = (e.clientY - r.top) * (c.height / r.height)
        
        curStroke.current.pts.push({ x, y })
        draw()
    }

    const onPointerUp = (e) => {
        if (canvasRef.current) {
            try { canvasRef.current.releasePointerCapture(e.pointerId) } catch (err) {}
        }
        
        if (curStroke.current) {
            // Save the current stroke to a local variable
            // because React state updaters are executed asynchronously.
            const finalStroke = curStroke.current
            setAnnotations(a => ({ 
                ...a, 
                [slideIdx]: [...(a[slideIdx] || []), finalStroke] 
            }))
            curStroke.current = null // Safely clear the ref now
        }
        draw()
    }

    const toggleFullscreen = () => {
        if (!document.fullscreenElement) {
            containerRef.current.requestFullscreen().catch(err => {
                alert(`Error attempting to enable full-screen mode: ${err.message}`)
            })
        } else {
            document.exitFullscreen()
        }
    }

    return (
        <div ref={containerRef} className="fixed inset-0 bg-[#020617] flex flex-col items-center justify-center select-none overflow-hidden">
            {/* ── Immersive Background ── */}
            <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_50%_50%,#1e1b4b_0%,#020617_100%)] opacity-40 shrink-0 pointer-events-none" />

            {/* ── Top Navigation Bar (Floating) ── */}
            <div className={`fixed top-6 left-1/2 -translate-x-1/2 z-[100] transition-all duration-500 transform ${showUI ? 'translate-y-0 opacity-100' : '-translate-y-24 opacity-0 pointer-events-none'}`}>
                <div className="flex items-center gap-4 bg-gray-950/80 backdrop-blur-xl px-5 py-2.5 rounded-[2rem] border border-white/10 shadow-3xl">
                    <Link to="/dashboard" className="p-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-full transition-all">
                        <ArrowLeft className="w-5 h-5" />
                    </Link>
                    <div className="w-px h-6 bg-white/10" />
                    <span className="text-sm font-bold text-gray-200 tracking-tight max-w-[200px] truncate">{title}</span>
                    <div className="w-px h-6 bg-white/10" />
                    <span className="text-xs font-mono text-gray-500 px-2">PG {slideIdx + 1} / {pages.length}</span>
                    <div className="w-px h-6 bg-white/10" />
                    <button 
                        onClick={handleSave} 
                        disabled={isSaving}
                        className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white px-5 py-2 rounded-full text-xs font-black transition-all shadow-lg active:scale-95 disabled:opacity-50"
                    >
                        <Save className="w-4 h-4" /> {isSaving ? '...' : 'SAVE'}
                    </button>
                    <button onClick={toggleFullscreen} className="p-2 text-gray-400 hover:text-white hover:bg-white/5 rounded-full transition-all">
                        <Maximize className="w-5 h-5" />
                    </button>
                </div>
            </div>

            {/* ── PDF / Canvas Container (Full Size) ── */}
            <div className="w-full h-full flex flex-col items-center justify-center p-0 sm:p-4 z-10 transition-all duration-500">
                <div className="relative group/canvas w-fit h-fit max-w-full max-h-full">
                    {pages[slideIdx] ? (
                        <div className="relative shadow-[0_0_100px_rgba(0,0,0,0.5)] bg-white overflow-hidden rounded-sm transition-transform duration-500">
                            <canvas 
                                key={`pdf-page-${slideIdx}`}
                                ref={canvasRef} 
                                onPointerDown={onPointerDown} 
                                onPointerMove={onPointerMove} 
                                onPointerUp={onPointerUp}
                                className="max-w-[100vw] max-h-[100vh] w-auto h-auto object-contain cursor-crosshair block"
                                style={{ 
                                    cursor: tool === 'eraser' ? 'url("https://img.icons8.com/material-rounded/24/eraser.png") 12 12, cell' : 'crosshair',
                                    touchAction: 'none'
                                }}
                            />
                        </div>
                    ) : (
                        <div className="flex flex-col items-center gap-4 text-violet-400">
                            <div className="w-12 h-12 border-4 border-violet-500/20 border-t-violet-500 rounded-full animate-spin" />
                            <span className="text-sm font-bold uppercase tracking-widest animate-pulse">Loading document...</span>
                        </div>
                    )}

                    {/* Page Navigation Buttons (Overlay) */}
                    <button 
                        onClick={() => setSlideIdx(i => Math.max(0, i - 1))}
                        disabled={slideIdx === 0}
                        className={`absolute left-[-80px] top-1/2 -translate-y-1/2 p-5 bg-gray-900/60 backdrop-blur-md text-white rounded-full transition-all hover:bg-violet-600 hover:scale-110 disabled:opacity-0 z-[60] shadow-2xl ${showUI ? '' : 'translate-x-[-100px] opacity-0'}`}
                    >
                        <ChevronLeft className="w-10 h-10" />
                    </button>
                    <button 
                        onClick={() => setSlideIdx(i => Math.min(pages.length - 1, i + 1))}
                        disabled={slideIdx === pages.length - 1}
                        className={`absolute right-[-80px] top-1/2 -translate-y-1/2 p-5 bg-gray-900/60 backdrop-blur-md text-white rounded-full transition-all hover:bg-violet-600 hover:scale-110 disabled:opacity-0 z-[60] shadow-2xl ${showUI ? '' : 'translate-x-[100px] opacity-0'}`}
                    >
                        <ChevronRight className="w-10 h-10" />
                    </button>
                </div>
            </div>

            {/* ── Floating Tool Palette (Centered Bottom) ── */}
            <div className={`fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] transition-all duration-500 transform ${showUI ? 'translate-y-0 opacity-100' : 'translate-y-24 opacity-0 pointer-events-none'}`}>
                <div className="flex flex-col items-center gap-4">
                    {/* Color Presets */}
                    <div className="flex items-center gap-2.5 bg-gray-950/80 backdrop-blur-xl px-5 py-3 rounded-full border border-white/10 shadow-2xl">
                        {COLORS.map(c => (
                            <button 
                                key={c} 
                                onClick={() => setColor(c)}
                                className={`w-7 h-7 rounded-full border-2 transition-all transform hover:scale-125 ${color === c ? 'scale-125 border-white shadow-[0_0_15px_rgba(255,255,255,0.4)]' : 'border-transparent opacity-60 hover:opacity-100'}`} 
                                style={{ backgroundColor: c }}
                            />
                        ))}
                    </div>

                    {/* Tools & Size */}
                    <div className="flex items-center gap-4 bg-gray-950/80 backdrop-blur-xl p-2 rounded-[2.5rem] border border-white/10 shadow-2xl">
                        <div className="flex items-center bg-gray-900/50 rounded-full p-1 border border-white/5">
                            {[
                                { id: 'pen', icon: Pencil },
                                { id: 'highlighter', icon: Highlighter },
                                { id: 'eraser', icon: Eraser }
                            ].map(t => (
                                <button 
                                    key={t.id} 
                                    onClick={() => setTool(t.id)} 
                                    className={`p-3.5 rounded-full transition-all duration-300 ${tool === t.id ? 'bg-violet-600 text-white shadow-xl scale-110' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}
                                >
                                    <t.icon className="w-5 h-5" />
                                </button>
                            ))}
                        </div>
                        
                        <div className="w-px h-8 bg-white/10" />

                        <div className="flex items-center gap-3 px-4">
                            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Size</span>
                            <input 
                                type="range" min="1" max="20" 
                                value={penSize} 
                                onChange={(e) => setPenSize(parseInt(e.target.value))}
                                className="w-24 accent-violet-500 opacity-60 hover:opacity-100 transition-opacity"
                            />
                        </div>

                        <div className="w-px h-8 bg-white/10" />
                        
                        <button 
                            onClick={() => setShowUI(false)}
                            className="p-3.5 text-gray-500 hover:text-white hover:bg-white/5 rounded-full transition-all"
                            title="Hide Toolbar"
                        >
                            <Layout className="w-5 h-5" />
                        </button>
                    </div>
                </div>
            </div>

            {/* ── Status Messages & Feedbacks ── */}
            <div id="save-feedback" className="fixed top-24 left-1/2 -translate-x-1/2 z-[110] transition-all duration-500 opacity-0 pointer-events-none">
                <div className="bg-emerald-500 text-white px-6 py-2 rounded-full font-bold text-xs shadow-2xl shadow-emerald-500/20 flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                    SAVED TO CLOUD
                </div>
            </div>

            {!showUI && (
                <button 
                    onClick={() => setShowUI(true)}
                    className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] p-4 bg-violet-600 text-white rounded-full shadow-3xl hover:scale-110 active:scale-95 transition-all opacity-40 hover:opacity-100 group"
                >
                    <Layout className="w-6 h-6" />
                    <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 bg-gray-900 border border-white/10 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">Show Toolbar</span>
                </button>
            )}
        </div>
    )
}
