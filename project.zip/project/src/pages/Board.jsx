import { useState, useRef, useEffect, useCallback } from 'react'
import { Link, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import {
    Pencil, Highlighter, Eraser, Type, Hand, MousePointer2,
    Undo2, Redo2, Trash2, ZoomIn, ZoomOut,
    FileUp, ArrowLeft, X, Minus, Plus, FileDown,
    ChevronLeft, ChevronRight, Maximize,
    PanelLeft, Square, Circle, ArrowUpRight, Minus as LineIcon,
    StickyNote, Rows3, Columns3, GripVertical, Download, Save,
    Search, Image as ImageIcon
} from 'lucide-react'

// ─── Constants ───────────────────────────────────────────────
const TOOLS = [
    { id: 'select', icon: MousePointer2, label: 'Select', key: 'v' },
    { id: 'pan', icon: Hand, label: 'Pan', key: 'h' },
    { id: 'pen', icon: Pencil, label: 'Pen', key: 'p' },
    { id: 'highlighter', icon: Highlighter, label: 'Highlight', key: 'm' },
    { id: 'eraser', icon: Eraser, label: 'Eraser', key: 'e' },
    { id: 'text', icon: Type, label: 'Text', key: 't' },
    { id: 'sticky', icon: StickyNote, label: 'Sticky Note', key: 'n' },
]

const SHAPES = [
    { id: 'rect', icon: Square, label: 'Rectangle' },
    { id: 'ellipse', icon: Circle, label: 'Ellipse' },
    { id: 'line', icon: LineIcon, label: 'Line' },
    { id: 'arrow', icon: ArrowUpRight, label: 'Arrow' },
]

const COLORS = [
    '#ffffff', '#f87171', '#fb923c', '#fbbf24', '#4ade80',
    '#22d3ee', '#60a5fa', '#a78bfa', '#f472b6', '#94a3b8',
]

const BG_TYPES = ['plain', 'grid', 'dotted', 'lined']

const STICKY_COLORS = ['#fbbf24', '#4ade80', '#60a5fa', '#f472b6', '#a78bfa', '#fb923c']

let _id = Date.now()
const uid = () => ++_id

// ─── Cursors ─────────────────────────────────────────────────
const PEN_CURSOR = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 24 24' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z' stroke='black' stroke-width='4'/%3E%3Cpath d='M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z' stroke='white' stroke-width='2'/%3E%3C/svg%3E") 0 24, crosshair`
const ERASER_CURSOR = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='28' viewBox='0 0 24 24' fill='none' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.9-9.9c1-1 2.5-1 3.4 0l4.3 4.3c1 1 1 2.5 0 3.4l-9.9 9.9c-1 1-2.5 1-3.4 0Z' stroke='black' stroke-width='4'/%3E%3Cpath d='M22 21H7' stroke='black' stroke-width='4'/%3E%3Cpath d='m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.9-9.9c1-1 2.5-1 3.4 0l4.3 4.3c1 1 1 2.5 0 3.4l-9.9 9.9c-1 1-2.5 1-3.4 0Z' stroke='white' stroke-width='2'/%3E%3Cpath d='M22 21H7' stroke='white' stroke-width='2'/%3E%3C/svg%3E") 0 24, auto`

// ─── Helpers ─────────────────────────────────────────────────
function s2w(sx, sy, cam) {
    return { x: (sx - cam.x) / cam.z, y: (sy - cam.y) / cam.z }
}

function drawStroke(ctx, pts, color, width, opacity = 1) {
    if (!pts || pts.length < 2) return
    ctx.save()
    ctx.globalAlpha = opacity
    ctx.strokeStyle = color
    ctx.lineWidth = width
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
    ctx.beginPath()
    ctx.moveTo(pts[0].x, pts[0].y)
    for (let i = 1; i < pts.length - 1; i++) {
        const mx = (pts[i].x + pts[i + 1].x) / 2
        const my = (pts[i].y + pts[i + 1].y) / 2
        ctx.quadraticCurveTo(pts[i].x, pts[i].y, mx, my)
    }
    ctx.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y)
    ctx.stroke()
    ctx.restore()
}

function drawShape(ctx, shape) {
    ctx.save()
    ctx.strokeStyle = shape.color || '#fff'
    ctx.lineWidth = shape.size || 2
    ctx.globalAlpha = shape.opacity || 1
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'

    const x = Math.min(shape.x1, shape.x2)
    const y = Math.min(shape.y1, shape.y2)
    const w = Math.abs(shape.x2 - shape.x1)
    const h = Math.abs(shape.y2 - shape.y1)

    if (shape.fill) {
        ctx.fillStyle = shape.color || '#fff'
        ctx.globalAlpha = 0.1
        if (shape.shapeType === 'rect') ctx.fillRect(x, y, w, h)
        else if (shape.shapeType === 'ellipse') {
            ctx.beginPath()
            ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2)
            ctx.fill()
        }
    }

    ctx.globalAlpha = shape.opacity || 1
    if (shape.shapeType === 'rect') {
        ctx.beginPath()
        ctx.roundRect(x, y, w, h, 4)
        ctx.stroke()
    } else if (shape.shapeType === 'ellipse') {
        ctx.beginPath()
        ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2)
        ctx.stroke()
    } else if (shape.shapeType === 'line') {
        ctx.beginPath()
        ctx.moveTo(shape.x1, shape.y1)
        ctx.lineTo(shape.x2, shape.y2)
        ctx.stroke()
    } else if (shape.shapeType === 'arrow') {
        ctx.beginPath()
        ctx.moveTo(shape.x1, shape.y1)
        ctx.lineTo(shape.x2, shape.y2)
        ctx.stroke()
        const angle = Math.atan2(shape.y2 - shape.y1, shape.x2 - shape.x1)
        const headLen = Math.max(shape.size * 4, 12)
        ctx.beginPath()
        ctx.moveTo(shape.x2, shape.y2)
        ctx.lineTo(shape.x2 - headLen * Math.cos(angle - 0.4), shape.y2 - headLen * Math.sin(angle - 0.4))
        ctx.moveTo(shape.x2, shape.y2)
        ctx.lineTo(shape.x2 - headLen * Math.cos(angle + 0.4), shape.y2 - headLen * Math.sin(angle + 0.4))
        ctx.stroke()
    }
    ctx.restore()
}

function drawBg(ctx, w, h, cam, type) {
    ctx.fillStyle = '#0a0a0f'
    ctx.fillRect(0, 0, w, h)
    if (type === 'plain') return
    const gap = 40 * cam.z
    const ox = cam.x % gap
    const oy = cam.y % gap
    ctx.save()
    if (type === 'grid') {
        ctx.strokeStyle = 'rgba(255,255,255,0.04)'
        ctx.lineWidth = 1
        ctx.beginPath()
        for (let x = ox; x < w; x += gap) { ctx.moveTo(x, 0); ctx.lineTo(x, h) }
        for (let y = oy; y < h; y += gap) { ctx.moveTo(0, y); ctx.lineTo(w, y) }
        ctx.stroke()
    } else if (type === 'dotted') {
        ctx.fillStyle = 'rgba(255,255,255,0.08)'
        for (let x = ox; x < w; x += gap)
            for (let y = oy; y < h; y += gap)
                ctx.fillRect(x - 1, y - 1, 2, 2)
    } else if (type === 'lined') {
        ctx.strokeStyle = 'rgba(255,255,255,0.04)'
        ctx.lineWidth = 1
        ctx.beginPath()
        for (let y = oy; y < h; y += gap) { ctx.moveTo(0, y); ctx.lineTo(w, y) }
        ctx.stroke()
    }
    ctx.restore()
}

// ─── Board Component ─────────────────────────────────────────
export default function Board() {
    const { id: boardId } = useParams()
    const [boardTitle, setBoardTitle] = useState('Loading...')
    const [isSaving, setIsSaving] = useState(false)
    const [tool, setTool] = useState('pen')
    const [color, setColor] = useState('#ffffff')
    const [penSize, setPenSize] = useState(3)
    const [bg, setBg] = useState('grid')
    const [cam, setCam] = useState({ x: 0, y: 0, z: 1 })
    const [elements, setElements] = useState([])
    const [history, setHistory] = useState([[]])
    const [hIdx, setHIdx] = useState(0)
    const [selectedId, setSelectedId] = useState(null)
    const [draggingId, setDraggingId] = useState(null)
    const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
    const [editingText, setEditingText] = useState(null)
    const [editingStickyId, setEditingStickyId] = useState(null)
    const [resizingId, setResizingId] = useState(null)
    const [shapeFill, setShapeFill] = useState(false)
    const [stickyLayout, setStickyLayout] = useState('horizontal')
    const [paletteOrientation, setPaletteOrientation] = useState('horizontal')

    // Presentation Mode (PDF)
    const [pdfPages, setPdfPages] = useState([])
    const [slideIdx, setSlideIdx] = useState(0)
    const [presMode, setPresMode] = useState(false)
    const [annotations, setAnnotations] = useState({}) // { slideIdx: elements[] }
    const [presTool, setPresTool] = useState('pen')
    const [presColor, setPresColor] = useState('#f87171')

    const canvasRef = useRef(null)
    const olRef = useRef(null)
    const wrapRef = useRef(null)
    const imgInput = useRef(null)
    const pdfInput = useRef(null)
    const textInputRef = useRef(null)
    const pdfJs = useRef(null)
    const presCanvasRef = useRef(null)
    const imageCache = useRef(new Map())

    const isDrawTool = tool === 'pen' || tool === 'highlighter' || tool === 'eraser'
    const isShapeTool = ['rect', 'ellipse', 'line', 'arrow'].includes(tool)
    const [showColorSize, setShowColorSize] = useState(true)
    const [showBg, setShowBg] = useState(false)
    const [palettePos, setPalettePos] = useState({ x: window.innerWidth / 2, y: window.innerHeight - 80 })
    const [isDraggingPalette, setIsDraggingPalette] = useState(false)
    const saveTimeoutRef = useRef(null)

    const curStroke = useRef(null)
    const spaceDown = useRef(false)
    const panStart = useRef(null)
    const [iconSearch, setIconSearch] = useState('')
    const [iconResults, setIconResults] = useState([])
    const [searchingIcons, setSearchingIcons] = useState(false)
    const [showIconPanel, setShowIconPanel] = useState(false)

    const searchIcons = async (q) => {
        if (!q) return
        setSearchingIcons(true)
        try {
            const res = await fetch(`https://api.iconify.design/search?query=${q}&limit=32`)
            const data = await res.json()
            setIconResults(data.icons || [])
        } catch (e) { console.error('Icon search failed:', e) }
        setSearchingIcons(false)
    }

    const addIcon = async (iconName) => {
        const wx = (window.innerWidth / 2 - cam.x) / cam.z
        const wy = (window.innerHeight / 2 - cam.y) / cam.z
        addIconAtPosition(iconName, wx, wy)
        setShowIconPanel(false)
    }

    const addIconAtPosition = async (iconName, worldX, worldY) => {
        try {
            const res = await fetch(`https://api.iconify.design/get_icon?icon=${iconName}`)
            const data = await res.json()
            if (data.body) {
                // Ensure the SVG has proper dimensions and namespace
                const svgWidth = data.width || 32
                const svgHeight = data.height || 32
                const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${svgWidth}" height="${svgHeight}" viewBox="0 0 ${svgWidth} ${svgHeight}">${data.body}</svg>`
                
                // Robust base64 encoding
                const b64 = `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(svg)))}`
                
                const newEl = {
                    id: uid(),
                    type: 'image',
                    src: b64,
                    x: worldX - 50, // Center the 100px wide icon
                    y: worldY - 50, // Center the 100px high icon
                    w: 100,
                    h: 100,
                    last_edited: new Date().toISOString()
                }
                
                setElements(prevEls => {
                    const next = [...prevEls, newEl]
                    // We call pushHistory with the final elements array
                    // Using a slight delay to ensure batching or just calling it directly
                    // But better: use the functional setHistory to avoid stale state
                    setHistory(prevH => {
                        const hNext = [...prevH.slice(0, hIdx + 1), next]
                        if (hNext.length > 50) hNext.shift()
                        setHIdx(hNext.length - 1)
                        return hNext
                    })
                    return next
                })
                // Trigger an immediate draw call if elements didn't change enough to trigger useEffect
                setTimeout(draw, 0)
            }
        } catch (e) { console.error('Add icon failed:', e) }
    }

    const onBoardDrop = (e) => {
        e.preventDefault()
        const iconName = e.dataTransfer.getData('text/plain') || e.dataTransfer.getData('penta-icon')
        const rect = wrapRef.current.getBoundingClientRect()
        const wx = (e.clientX - rect.left - cam.x) / cam.z
        const wy = (e.clientY - rect.top - cam.y) / cam.z

        if (iconName && iconName.includes(':')) {
            addIconAtPosition(iconName, wx, wy)
            return
        }

        const files = e.dataTransfer.files
        if (files && files[0] && files[0].type.startsWith('image/')) {
            const reader = new FileReader()
            reader.onload = (re) => {
                const img = new Image()
                img.src = re.target.result
                img.onload = () => {
                    const newEl = {
                        id: uid(),
                        type: 'image',
                        src: re.target.result,
                        x: wx - 100,
                        y: wy - 100,
                        w: 200,
                        h: 200,
                        last_edited: new Date().toISOString()
                    }
                    pushHistory([...elements, newEl])
                }
            }
            reader.readAsDataURL(files[0])
        }
    }

    const onBoardDragOver = (e) => {
        e.preventDefault()
        e.dataTransfer.dropEffect = 'copy'
    }

    // ─── Fetch Board from Supabase ───
    // ─── Fetch Board Data ───
    useEffect(() => {
        const loadBoard = async () => {
            if (!boardId) return

            // 1. Try Local Hub first
            const localBoards = JSON.parse(localStorage.getItem('penta_local_boards') || '[]')
            const localMatch = localBoards.find(b => b.id === boardId)
            
            if (localMatch) {
                setBoardTitle(localMatch.title)
                if (Array.isArray(localMatch.content)) {
                    setElements(localMatch.content)
                    setHistory([localMatch.content])
                    setHIdx(0)
                }
                return
            }

            // 2. Try Cache for Cloud Boards (Offline Mode)
            const cache = JSON.parse(localStorage.getItem('penta_cloud_cache') || '{}')
            if (cache[boardId]) {
                const cached = cache[boardId]
                setBoardTitle(cached.title)
                setElements(cached.content || [])
                setHistory([cached.content || []])
            }

            // 3. Fetch from Supabase (Online Mode)
            const { data, error } = await supabase
                .from('boards')
                .select('*')
                .eq('id', boardId)
                .single()

            if (data) {
                setBoardTitle(data.title)
                if (data.content && Array.isArray(data.content)) {
                    setElements(data.content)
                    setHistory([data.content])
                    setHIdx(0)
                    
                    // Update Cache
                    const newCache = { ...JSON.parse(localStorage.getItem('penta_cloud_cache') || '{}'), [boardId]: data }
                    localStorage.setItem('penta_cloud_cache', JSON.stringify(newCache))
                }
            } else if (error && !cache[boardId]) {
                console.error('Error loading board:', error)
                setBoardTitle('Offline / Not Found')
            }
        }
        loadBoard()
    }, [boardId])

    // ─── Save Board ───
    // ─── Save Board Logic (Offline-First) ───
    const handleSave = async () => {
        if (!boardId || isSaving) return
        setIsSaving(true)

        // 1. Handle Local-Only Boards
        if (boardId.toString().startsWith('local-')) {
            const local = JSON.parse(localStorage.getItem('penta_local_boards') || '[]')
            const updated = local.map(b => b.id === boardId ? { ...b, content: elements, last_edited: new Date().toISOString() } : b)
            localStorage.setItem('penta_local_boards', JSON.stringify(updated))
            setIsSaving(false)
            return
        }

        // 2. Handle Cloud Boards
        // Update Cache First (so it's available offline)
        const cache = JSON.parse(localStorage.getItem('penta_cloud_cache') || '{}')
        if (cache[boardId]) {
            cache[boardId].content = elements
            cache[boardId].last_edited = new Date().toISOString()
            localStorage.setItem('penta_cloud_cache', JSON.stringify(cache))
        }

        // Try Supabase
        const { error } = await supabase
            .from('boards')
            .update({
                content: elements,
                last_edited: new Date().toISOString()
            })
            .eq('id', boardId)

        if (error) {
            console.warn('Network error, saved to local cache only.', error)
        }
        
        setIsSaving(false)
        const btn = document.getElementById('save-btn')
        if (btn) {
            btn.classList.add('bg-emerald-600', 'text-white')
            setTimeout(() => btn.classList.remove('bg-emerald-600', 'text-white'), 1000)
        }
    }

    // Auto-sync background listener
    useEffect(() => {
        const sync = () => { if (navigator.onLine) handleSave() }
        window.addEventListener('online', sync)
        return () => window.removeEventListener('online', sync)
    }, [elements])

    // ─── Auto Save Logic ───
    useEffect(() => {
        if (!boardId || elements.length === 0) return

        // Clear existing timeout
        if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current)

        // Set a new timeout to save after 2 seconds of inactivity
        saveTimeoutRef.current = setTimeout(() => {
            handleSave()
        }, 2000)

        return () => {
            if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current)
        }
    }, [elements, boardId])

    // ─── PDF.js setup ─────
    useEffect(() => {
        const script = document.createElement('script')
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js'
        script.onload = () => {
            pdfJs.current = window['pdfjs-dist/build/pdf']
            pdfJs.current.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js'
        }
        document.head.appendChild(script)
    }, [])

    const pushHistory = (newEls) => {
        setHistory(prevHistory => {
            const next = [...prevHistory.slice(0, hIdx + 1), newEls]
            if (next.length > 50) next.shift()
            setHIdx(next.length - 1)
            return next
        })
        setElements(newEls)
    }

    const undo = () => { if (hIdx > 0) { setHIdx(hIdx - 1); setElements(history[hIdx - 1]) } }
    const redo = () => { if (hIdx < history.length - 1) { setHIdx(hIdx + 1); setElements(history[hIdx + 1]) } }

    const resetZoom = () => setCam(c => ({ ...c, z: 1 }))
    const zoomIn = () => setCam(c => ({ ...c, z: Math.min(c.z * 1.2, 5) }))
    const zoomOut = () => setCam(c => ({ ...c, z: Math.max(c.z / 1.2, 0.1) }))

    const getPos = (e) => {
        const rect = wrapRef.current.getBoundingClientRect()
        return s2w(e.clientX - rect.left, e.clientY - rect.top, cam)
    }

    const onPointerDown = (e) => {
        try { e.target.setPointerCapture(e.pointerId) } catch (err) {}
        
        if (spaceDown.current || tool === 'pan' || e.button === 1) {
            panStart.current = { x: e.clientX - cam.x, y: e.clientY - cam.y }
            return
        }

        // If something is being edited, finalize it first but allow new action
        if (editingText) finalizeText()
        if (editingStickyId) { pushHistory([...elements]); setEditingStickyId(null) }

        const pos = getPos(e)
        
        // 1. Eraser Tool Logic
        if (tool === 'eraser') {
            const hit = [...elements].reverse().find(el => {
                if (el.type === 'stroke') {
                    return el.pts.some(p => Math.hypot(p.x - pos.x, p.y - pos.y) < 20 / cam.z)
                }
                if (el.type === 'sticky' || el.type === 'image') {
                    return pos.x >= el.x && pos.x <= el.x + el.w && pos.y >= el.y && pos.y <= el.y + el.h
                }
                if (el.type === 'text') {
                    const ctx = canvasRef.current.getContext('2d')
                    const fontSize = el.fontSize || 18
                    ctx.font = `600 ${fontSize}px Inter`
                    const maxWidth = el.w || 250
                    const lines = (el.text || '').split('\n')
                    let wrappedCount = 0
                    lines.forEach(p => {
                        let line = ''
                        const words = p.split(' ')
                        words.forEach(w => {
                            if (ctx.measureText(line + w).width > maxWidth) { wrappedCount++; line = w + ' ' }
                            else line += w + ' '
                        })
                        wrappedCount++
                    })
                    const height = wrappedCount * (fontSize + 4)
                    return pos.x >= el.x && pos.x <= el.x + maxWidth + 16 && pos.y >= el.y && pos.y <= el.y + height + 24
                }
                if (el.type === 'shape') {
                    const sx = Math.min(el.x1, el.x2), sy = Math.min(el.y1, el.y2)
                    const sw = Math.abs(el.x2 - el.x1), sh = Math.abs(el.y2 - el.y1)
                    return pos.x >= sx - 5 && pos.x <= sx + sw + 5 && pos.y >= sy - 5 && pos.y <= sy + sh + 5
                }
                return false
            })
            if (hit) {
                pushHistory(elements.filter(el => el.id !== hit.id))
            }
            curStroke.current = { type: 'eraser_active' } // Flag that we are erasing
            return
        }

        // 2. Existing element interaction (Select or Text Tool)
        if (tool === 'select' || tool === 'text') {
            // Check for resize handle first if something is selected
            if (selectedId) {
                const sel = elements.find(el => el.id === selectedId)
                if (sel && sel.type !== 'stroke') {
                    const hx = (sel.x1 !== undefined ? Math.max(sel.x1, sel.x2) : (sel.x + (sel.w || 200)))
                    const hy = (sel.y1 !== undefined ? Math.max(sel.y1, sel.y2) : (sel.y + (sel.h || 40)))
                    const shx = hx * cam.z + cam.x
                    const shy = hy * cam.z + cam.y
                    if (Math.hypot(e.clientX - shx, e.clientY - shy) < 20) {
                        setResizingId(selectedId)
                        return
                    }
                }
            }

            const hit = [...elements].reverse().find(el => {
                if (tool === 'text' && el.type !== 'text') return false
                if (el.type === 'image' || el.type === 'sticky') return pos.x >= el.x && pos.x <= el.x + el.w && pos.y >= el.y && pos.y <= el.y + el.h
                if (el.type === 'text') {
                    const ctx = canvasRef.current.getContext('2d')
                    const fontSize = el.fontSize || 18
                    ctx.font = `600 ${fontSize}px Inter`
                    const maxWidth = el.w || 250
                    const lines = (el.text || '').split('\n')
                    let wrappedCount = 0
                    lines.forEach(p => {
                        let line = ''
                        const words = p.split(' ')
                        words.forEach(w => {
                            if (ctx.measureText(line + w).width > maxWidth) { wrappedCount++; line = w + ' ' }
                            else line += w + ' '
                        })
                        wrappedCount++
                    })
                    const height = wrappedCount * (fontSize + 4)
                    return pos.x >= el.x && pos.x <= el.x + maxWidth + 16 && pos.y >= el.y && pos.y <= el.y + height + 24
                }
                if (el.type === 'shape') {
                    const sx = Math.min(el.x1, el.x2), sy = Math.min(el.y1, el.y2)
                    const sw = Math.abs(el.x2 - el.x1), sh = Math.abs(el.y2 - el.y1)
                    return pos.x >= sx - 5 && pos.x <= sx + sw + 5 && pos.y >= sy - 5 && pos.y <= sy + sh + 5
                }
                return false
            })

            if (hit) {
                // If using text tool on a text element, edit it
                if (tool === 'text' && hit.type === 'text') {
                    setElements(els => els.filter(el => el.id !== hit.id))
                    setEditingText(hit)
                    return
                }
                
                // Otherwise, handle selection/dragging
                setSelectedId(hit.id)
                setDraggingId(hit.id)
                setDragOffset({ x: pos.x - (hit.x1 || hit.x), y: pos.y - (hit.y1 || hit.y) })
                return // Exit early for hit interaction
            } else {
                setSelectedId(null)
            }
            
            // If Text tool and no hit, start new text creation
            if (tool === 'text') {
                setEditingText({ x: pos.x, y: pos.y, text: '', fontSize: 18, w: 250 })
                return
            }
            
            if (tool === 'select') return
        }

        // 2. Tool-specific creation
        if (isDrawTool) {
            curStroke.current = { id: uid(), type: 'stroke', tool, pts: [pos], color, size: tool === 'highlighter' ? penSize * 2 : penSize, opacity: tool === 'highlighter' ? 0.35 : 1 }
        } else if (isShapeTool) {
            curStroke.current = { id: uid(), type: 'shape', shapeType: tool, x1: pos.x, y1: pos.y, x2: pos.x, y2: pos.y, color, size: penSize, fill: shapeFill, opacity: 1 }
        } else if (tool === 'sticky') {
            const el = { id: uid(), type: 'sticky', x: pos.x - 75, y: pos.y - 75, w: 150, h: 150, text: '', stickyColor: STICKY_COLORS[Math.floor(Math.random() * STICKY_COLORS.length)] }
            pushHistory([...elements, el]); setEditingStickyId(el.id)
        }
    }

    const onPointerMove = (e) => {
        if (e.buttons === 0 && (panStart.current || draggingId || curStroke.current || resizingId)) {
            onPointerUp(e)
            return
        }
        if (panStart.current) { setCam(c => ({ ...c, x: e.clientX - panStart.current.x, y: e.clientY - panStart.current.y })); return }
        const pos = getPos(e)

        if (resizingId) {
            setElements(els => els.map(el => {
                if (el.id !== resizingId) return el
                if (el.type === 'shape') {
                    return { ...el, x2: pos.x, y2: pos.y }
                }
                if (el.type === 'image' || el.type === 'sticky') {
                    return { ...el, w: Math.max(20, pos.x - el.x), h: Math.max(20, pos.y - el.y) }
                }
                if (el.type === 'text') {
                    return { ...el, w: Math.max(50, pos.x - el.x) }
                }
                return el
            }))
            return
        }

        if (draggingId) {
            setElements(els => els.map(el => {
                if (el.id !== draggingId) return el
                if (el.type === 'shape') {
                    const dx = pos.x - dragOffset.x - el.x1, dy = pos.y - dragOffset.y - el.y1
                    return { ...el, x1: el.x1 + dx, y1: el.y1 + dy, x2: el.x2 + dx, y2: el.y2 + dy }
                }
                return { ...el, x: pos.x - dragOffset.x, y: pos.y - dragOffset.y }
            }))
            return
        }

        if (tool === 'eraser' && curStroke.current?.type === 'eraser_active') {
            const hit = [...elements].reverse().find(el => {
                if (el.type === 'stroke') {
                    return el.pts.some(p => Math.hypot(p.x - pos.x, p.y - pos.y) < 20 / cam.z)
                }
                if (el.type === 'sticky' || el.type === 'image') {
                    return pos.x >= el.x && pos.x <= el.x + el.w && pos.y >= el.y && pos.y <= el.y + el.h
                }
                if (el.type === 'text') {
                    const ctx = canvasRef.current.getContext('2d')
                    const fontSize = el.fontSize || 18
                    ctx.font = `600 ${fontSize}px Inter`
                    const maxWidth = el.w || 250
                    const lines = (el.text || '').split('\n')
                    let wrappedCount = 0
                    lines.forEach(p => {
                        let line = ''
                        const words = p.split(' ')
                        words.forEach(w => {
                            if (ctx.measureText(line + w).width > maxWidth) { wrappedCount++; line = w + ' ' }
                            else line += w + ' '
                        })
                        wrappedCount++
                    })
                    const height = wrappedCount * (fontSize + 4)
                    return pos.x >= el.x && pos.x <= el.x + maxWidth + 16 && pos.y >= el.y && pos.y <= el.y + height + 24
                }
                if (el.type === 'shape') {
                    const sx = Math.min(el.x1, el.x2), sy = Math.min(el.y1, el.y2)
                    const sw = Math.abs(el.x2 - el.x1), sh = Math.abs(el.y2 - el.y1)
                    return pos.x >= sx - 5 && pos.x <= sx + sw + 5 && pos.y >= sy - 5 && pos.y <= sy + sh + 5
                }
                return false
            })
            if (hit) {
                setElements(els => els.filter(el => el.id !== hit.id))
            }
            return
        }

        if (!curStroke.current) return
        if (isDrawTool) curStroke.current.pts.push(pos)
        else if (isShapeTool) { curStroke.current.x2 = pos.x; curStroke.current.y2 = pos.y }
        draw()
    }

    const onPointerUp = (e) => {
        try { if (e && e.pointerId) e.target.releasePointerCapture(e.pointerId) } catch (err) {}
        if (panStart.current) { panStart.current = null; return }
        if (resizingId) { setResizingId(null); pushHistory([...elements]); return }
        if (draggingId) { setDraggingId(null); pushHistory([...elements]); return }
        if (tool === 'eraser') {
            if (curStroke.current?.type === 'eraser_active') {
                pushHistory([...elements])
            }
            curStroke.current = null
            return
        }
        if (!curStroke.current) return
        pushHistory([...elements, curStroke.current]); curStroke.current = null; draw()
    }

    const onWheel = useCallback((e) => {
        if (e.ctrlKey || e.metaKey) {
            e.preventDefault()
            const zoomSpeed = 0.001
            const factor = Math.exp(-e.deltaY * zoomSpeed)
            const newZ = Math.min(Math.max(cam.z * factor, 0.1), 5)

            const rect = wrapRef.current.getBoundingClientRect()
            const mx = e.clientX - rect.left
            const my = e.clientY - rect.top

            const wx = (mx - cam.x) / cam.z
            const wy = (my - cam.y) / cam.z

            setCam({
                x: mx - wx * newZ,
                y: my - wy * newZ,
                z: newZ
            })
        } else {
            setCam(c => ({
                ...c,
                x: c.x - e.deltaX,
                y: c.y - e.deltaY
            }))
        }
    }, [cam.x, cam.y, cam.z])

    useEffect(() => {
        const wrap = wrapRef.current
        if (!wrap) return
        wrap.addEventListener('wheel', onWheel, { passive: false })
        return () => wrap.removeEventListener('wheel', onWheel)
    }, [onWheel])

    const finalizeText = useCallback(() => {
        if (editingText) {
            if (editingText.text.trim()) {
                const newTextEl = { 
                    ...editingText, 
                    id: editingText.id || uid(), 
                    type: 'text', 
                    fontSize: 18, 
                    color: editingText.color || color 
                }
                pushHistory([...elements, newTextEl])
            }
            setEditingText(null)
        }
    }, [editingText, elements, color, pushHistory])

    useEffect(() => {
        if (editingText && textInputRef.current) {
            textInputRef.current.focus()
        }
    }, [editingText])


    const onPdfUpload = async (e) => {
        const file = e.target.files?.[0]; if (!file || !pdfJs.current) return
        const r = new FileReader()
        r.onload = async () => {
            const pdf = await pdfJs.current.getDocument(r.result).promise
            const pages = []
            for (let i = 1; i <= pdf.numPages; i++) {
                const pg = await pdf.getPage(i); const vp = pg.getViewport({ scale: 1.5 })
                const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height
                await pg.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise
                pages.push({ src: c.toDataURL(), width: vp.width, height: vp.height })
            }
            setPdfPages(pages); setSlideIdx(0); setPresMode(true)
        }
        r.readAsArrayBuffer(file)
    }

    const draw = useCallback(() => {
        const c = canvasRef.current; 
        const ol = olRef.current; 
        if (!c || !ol) return
        
        const ctx = c.getContext('2d'); 
        const octx = ol.getContext('2d')
        const w = window.innerWidth, h = window.innerHeight

        // Only resize if dimensions changed to avoid clearing the canvas unnecessarily
        if (c.width !== w || c.height !== h) {
            c.width = ol.width = w
            c.height = ol.height = h
        } else {
            // If not resizing, we must manually clear the canvases
            // Main canvas is cleared by drawBg below (fillRect)
            octx.clearRect(0, 0, w, h)
        }

        drawBg(ctx, w, h, cam, bg)
        ctx.save(); ctx.translate(cam.x, cam.y); ctx.scale(cam.z, cam.z)

        elements.forEach(el => {
            if (el.type === 'stroke') {
                drawStroke(ctx, el.pts, el.color, el.size, el.opacity)
            } else if (el.type === 'shape') {
                drawShape(ctx, el)
            } else if (el.type === 'text') {
                ctx.fillStyle = el.color || '#fff'; 
                ctx.font = `600 ${el.fontSize || 18}px Inter`;
                const lines = (el.text || '').split('\n')
                const maxWidth = el.w || 250
                const lineHeight = (el.fontSize || 18) + 4
                let currentY = el.y + 24

                lines.forEach(paragraph => {
                    const words = paragraph.split(' ')
                    let line = ''
                    for (let n = 0; n < words.length; n++) {
                        const testLine = line + words[n] + ' '
                        const metrics = ctx.measureText(testLine)
                        if (metrics.width > maxWidth && n > 0) {
                            ctx.fillText(line, el.x + 8, currentY)
                            line = words[n] + ' '
                            currentY += lineHeight
                        } else {
                            line = testLine
                        }
                    }
                    ctx.fillText(line, el.x + 8, currentY)
                    currentY += lineHeight
                })
            } else if (el.type === 'image') {
                let img = imageCache.current.get(el.src)
                if (!img) {
                    img = new Image()
                    img.src = el.src
                    img.onload = () => {
                        imageCache.current.set(el.src, img)
                        // Trigger a redraw. We use elements as a trigger, but since we are
                        // inside a callback, it's safer to just call the draw function again
                        // or trigger a state refresh.
                        draw()
                    }
                    img.onerror = () => {
                        console.error('Failed to load image:', el.src.substring(0, 50) + '...')
                        imageCache.current.set(el.src, 'error')
                    }
                }
                if (img && img.complete && img.naturalWidth > 0) {
                    ctx.drawImage(img, el.x, el.y, el.w, el.h)
                }
            } else if (el.type === 'sticky') {
                ctx.save(); 
                ctx.fillStyle = el.stickyColor || '#fbbf24'; 
                ctx.beginPath(); 
                if (ctx.roundRect) ctx.roundRect(el.x, el.y, el.w, el.h, 8);
                else ctx.rect(el.x, el.y, el.w, el.h);
                ctx.fill()
                
                ctx.fillStyle = '#1a1a1a'; 
                ctx.font = '500 14px Inter'
                const words = (el.text || '').split(' '); 
                let line = '', y = el.y + 25
                words.forEach(word => {
                    const test = line + word + ' '; 
                    if (ctx.measureText(test).width > el.w - 20) { 
                        ctx.fillText(line, el.x + 10, y); 
                        line = word + ' '; 
                        y += 18 
                    } else line = test
                })
                ctx.fillText(line, el.x + 10, y); 
                ctx.restore()
            }
        })
        if (curStroke.current) { 
            if (isDrawTool) drawStroke(ctx, curStroke.current.pts, curStroke.current.color, curStroke.current.size, curStroke.current.opacity); 
            else if (curStroke.current.type === 'shape') drawShape(ctx, curStroke.current) 
        }
        ctx.restore()
        if (selectedId) {
            octx.save(); octx.translate(cam.x, cam.y); octx.scale(cam.z, cam.z); octx.strokeStyle = '#818cf8', octx.lineWidth = 2 / cam.z
            const sel = elements.find(e => e.id === selectedId)
            if (sel) {
                let hx, hy
                if (sel.type === 'shape') { 
                    const sx = Math.min(sel.x1, sel.x2), sy = Math.min(sel.y1, sel.y2)
                    const sw = Math.abs(sel.x2 - sel.x1), sh = Math.abs(sel.y2 - sel.y1)
                    octx.strokeRect(sx - 4, sy - 4, sw + 8, sh + 8)
                    hx = Math.max(sel.x1, sel.x2)
                    hy = Math.max(sel.y1, sel.y2)
                } else {
                    const sw = sel.w || 200, sh = sel.h || 40
                    octx.strokeRect(sel.x - 4, sel.y - 4, sw + 8, sh + 8)
                    hx = sel.x + sw
                    hy = sel.y + sh
                }
                
                // Draw Resize Handle
                if (sel.type !== 'stroke') {
                    octx.fillStyle = '#818cf8'
                    octx.beginPath()
                    octx.arc(hx + 4, hy + 4, 6 / cam.z, 0, Math.PI * 2)
                    octx.fill()
                    octx.strokeStyle = '#fff'
                    octx.lineWidth = 1 / cam.z
                    octx.stroke()
                }
            }
            octx.restore()
        }
    }, [elements, cam, bg, selectedId])

    useEffect(() => { draw(); window.addEventListener('resize', draw); return () => window.removeEventListener('resize', draw) }, [draw])

    useEffect(() => {
        const kdown = (e) => {
            if (e.code === 'Space') spaceDown.current = true
            
            // Tool Shortcuts
            if (!editingText && !editingStickyId) {
                const toolMatch = TOOLS.find(t => t.key === e.key.toLowerCase())
                if (toolMatch) setTool(toolMatch.id)
            }

            if (e.ctrlKey || e.metaKey) {
                if (e.key === 'z') { e.preventDefault(); undo() }
                if (e.key === 'y') { e.preventDefault(); redo() }
                if (e.key === 's') { e.preventDefault(); handleSave() }
            }
            if (e.key === 'Delete' || e.key === 'Backspace') { if (selectedId && !editingText && !editingStickyId) { pushHistory(elements.filter(el => el.id !== selectedId)); setSelectedId(null) } }
        }
        const kup = (e) => { if (e.code === 'Space') spaceDown.current = false }
        window.addEventListener('keydown', kdown); window.addEventListener('keyup', kup)
        return () => { window.removeEventListener('keydown', kdown); window.removeEventListener('keyup', kup) }
    }, [elements, hIdx, selectedId, editingText, editingStickyId])

    const exportBoardPdf = async () => {
        const s = document.createElement('script'); s.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'
        s.onload = () => { const { jsPDF } = window.jspdf; const c = canvasRef.current; const doc = new jsPDF({ orientation: 'l', unit: 'px', format: [c.width, c.height] }); doc.addImage(c.toDataURL('image/jpeg', 0.95), 'JPEG', 0, 0, c.width, c.height); doc.save('penta-whiteboard.pdf') }
        document.head.appendChild(s)
    }

    // Presentation mode drawing
    const drawPres = useCallback(() => {
        const c = presCanvasRef.current; if (!c || !pdfPages[slideIdx]) return
        const ctx = c.getContext('2d'); const img = new Image(); img.src = pdfPages[slideIdx].src
        img.onload = () => {
            ctx.clearRect(0, 0, c.width, c.height); ctx.drawImage(img, 0, 0, c.width, c.height)
            const annos = annotations[slideIdx] || []
            annos.forEach(el => drawStroke(ctx, el.pts, el.color, el.size, el.opacity))
            if (curPresStroke.current) drawStroke(ctx, curPresStroke.current.pts, curPresStroke.current.color, curPresStroke.current.size, curPresStroke.current.opacity)
        }
    }, [pdfPages, slideIdx, annotations])

    useEffect(() => { if (presMode) drawPres() }, [presMode, slideIdx, annotations, drawPres])

    const curPresStroke = useRef(null)
    const onPresPointerDown = (e) => {
        try { e.target.setPointerCapture(e.pointerId) } catch (err) {}
        const r = presCanvasRef.current.getBoundingClientRect()
        const x = (e.clientX - r.left) * (presCanvasRef.current.width / r.width)
        const y = (e.clientY - r.top) * (presCanvasRef.current.height / r.height)
        curPresStroke.current = { pts: [{ x, y }], color: presColor, size: presTool === 'highlighter' ? 12 : 3, opacity: presTool === 'highlighter' ? 0.35 : 1 }
    }
    const onPresPointerMove = (e) => {
        if (e.buttons === 0 && curPresStroke.current) {
            onPresPointerUp(e)
            return
        }
        if (!curPresStroke.current) return
        const r = presCanvasRef.current.getBoundingClientRect()
        curPresStroke.current.pts.push({ x: (e.clientX - r.left) * (r.width ? presCanvasRef.current.width / r.width : 1), y: (e.clientY - r.top) * (r.height ? presCanvasRef.current.height / r.height : 1) })
        drawPres()
    }
    const onPresPointerUp = (e) => {
        try { if (e && e.pointerId) e.target.releasePointerCapture(e.pointerId) } catch (err) {}
        if (curPresStroke.current) {
            const finalStroke = curPresStroke.current
            setAnnotations(a => ({ ...a, [slideIdx]: [...(a[slideIdx] || []), finalStroke] }))
            curPresStroke.current = null
            drawPres() 
        }
    }

    return (
        <div className="h-screen w-screen bg-[#0a0a0f] flex flex-col overflow-hidden select-none">
            <div className="flex items-center justify-between px-3 py-1.5 bg-gray-900/80 backdrop-blur-md border-b border-white/5 z-30 gap-2">
                <div className="flex items-center gap-3">
                    <Link to="/dashboard" className="flex items-center gap-1.5 text-gray-400 hover:text-white text-sm shrink-0"><ArrowLeft className="w-4 h-4" /> Dashboard</Link>
                    <div className="w-px h-4 bg-white/10" />
                    <span className="text-sm font-bold text-gray-200 truncate max-w-[150px]">{boardTitle}</span>
                </div>
                <div className="flex items-center gap-1 bg-gray-800/60 rounded-xl px-2 py-1 border border-white/5">
                    {TOOLS.map(t => (
                        <button key={t.id} onClick={() => setTool(t.id)} className={`p-2 rounded-lg transition-all ${tool === t.id ? 'bg-violet-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'}`} title={t.label}><t.icon className="w-4 h-4" /></button>
                    ))}
                    <div className="w-px h-6 bg-white/10 mx-1" />
                    {SHAPES.map(s => (
                        <button key={s.id} onClick={() => setTool(s.id)} className={`p-2 rounded-lg transition-all ${tool === s.id ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400 hover:text-white'}`} title={s.id}><s.icon className="w-4 h-4" /></button>
                    ))}
                    <div className="w-px h-6 bg-white/10 mx-1" />
                    <div className="flex items-center gap-2 px-1">
                        <span className="text-[10px] font-black text-gray-500 uppercase tracking-tighter">Size</span>
                        <input type="range" min="1" max="30" value={penSize} onChange={e => setPenSize(+e.target.value)} className="w-12 accent-violet-500 h-1 bg-white/10 rounded-full appearance-none cursor-pointer" />
                    </div>
                    <div className="w-px h-6 bg-white/10 mx-1" />
                    <button 
                        onClick={() => setShapeFill(!shapeFill)} 
                        className={`px-2 py-1 rounded-lg text-[10px] font-black tracking-widest transition-all ${shapeFill ? 'bg-violet-600 text-white shadow-lg' : 'bg-white/5 text-gray-500 hover:text-gray-300'}`}
                    >
                        FILL {shapeFill ? 'ON' : 'OFF'}
                    </button>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                    <button id="save-btn" onClick={handleSave} disabled={isSaving} className={`flex items-center justify-center gap-2 px-3 py-1.5 rounded-lg text-sm font-bold transition-all min-w-[85px] ${isSaving ? 'opacity-50' : 'bg-gray-800 text-gray-300 hover:bg-violet-600 hover:text-white'}`}>
                        {isSaving ? (
                            <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                        ) : (
                            <>
                                <Save className="w-4 h-4" />
                                <span>Save</span>
                            </>
                        )}
                    </button>
                    <div className="w-px h-6 bg-white/10 mx-1" />
                    <button onClick={undo} disabled={hIdx <= 0} className="p-2 text-gray-400 disabled:opacity-30"><Undo2 className="w-4 h-4" /></button>
                    <button onClick={redo} disabled={hIdx >= history.length - 1} className="p-2 text-gray-400 disabled:opacity-30"><Redo2 className="w-4 h-4" /></button>
                    <button onClick={() => setShowBg(!showBg)} className={`p-2 rounded-lg ${showBg ? 'bg-violet-600' : 'text-gray-400'}`}><PanelLeft className="w-4 h-4" /></button>
                    <button onClick={() => pdfInput.current?.click()} className="p-2 text-gray-400"><FileUp className="w-4 h-4" /></button>
                    <button onClick={exportBoardPdf} className="p-2 text-gray-400"><FileDown className="w-4 h-4" /></button>
                    <button onClick={() => setShowIconPanel(!showIconPanel)} className={`p-2 rounded-lg transition-all ${showIconPanel ? 'bg-violet-600 text-white' : 'text-gray-400'}`}><ImageIcon className="w-4 h-4" /></button>
                    <button onClick={() => { if (!document.fullscreenElement) document.documentElement.requestFullscreen(); else document.exitFullscreen() }} className="p-2 text-gray-400"><Maximize className="w-4 h-4" /></button>
                </div>
            </div>

            {showIconPanel && (
                <div className="absolute top-16 right-4 z-[100] w-72 bg-gray-900/95 backdrop-blur-xl rounded-2xl border border-white/10 shadow-3xl flex flex-col overflow-hidden max-h-[70vh]">
                    <div className="p-4 border-b border-white/5 space-y-3">
                        <div className="flex items-center justify-between">
                            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest">Icon Search</h3>
                            <button onClick={() => setShowIconPanel(false)} className="p-1 text-gray-500 hover:text-white"><X className="w-4 h-4" /></button>
                        </div>
                        <div className="relative">
                            <input 
                                type="text" 
                                placeholder="Search icons (e.g. arrows, home, tech)..." 
                                value={iconSearch}
                                onChange={e => { setIconSearch(e.target.value); if (e.target.value.length > 2) searchIcons(e.target.value) }}
                                className="w-full bg-black/40 border border-white/5 rounded-xl py-2 pl-9 pr-4 text-xs text-white placeholder:text-gray-600 focus:border-violet-500/50 transition-all outline-none"
                            />
                            <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-500" />
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3 grid grid-cols-4 gap-2 scrollbar-thin scrollbar-track-transparent scrollbar-thumb-white/10">
                        {searchingIcons ? (
                            <div className="col-span-4 py-8 flex items-center justify-center">
                                <div className="w-5 h-5 border-2 border-violet-500/20 border-t-violet-500 rounded-full animate-spin" />
                            </div>
                        ) : iconResults.length > 0 ? (
                            iconResults.map(icon => (
                                <button 
                                    key={icon} 
                                    onClick={() => addIcon(icon)}
                                    draggable="true"
                                    onDragStart={(e) => {
                                        e.dataTransfer.setData('penta-icon', icon)
                                        e.dataTransfer.setData('text/plain', icon)
                                        e.dataTransfer.effectAllowed = 'copy'
                                    }}
                                    className="aspect-square bg-white/5 hover:bg-violet-600/20 rounded-lg p-2 transition-all flex items-center justify-center group cursor-grab active:cursor-grabbing"
                                    title={icon}
                                >
                                    <img 
                                        src={`https://api.iconify.design/${icon.replace(':', '/')}.svg?color=white`} 
                                        className="w-full h-full object-contain group-hover:scale-110 transition-transform pointer-events-none"
                                        alt=""
                                    />
                                </button>
                            ))
                        ) : iconSearch.length > 2 ? (
                            <div className="col-span-4 py-8 text-center text-xs text-gray-600">No icons found</div>
                        ) : (
                            <div className="col-span-4 py-8 text-center text-xs text-gray-600 italic">Try searching for something...</div>
                        )}
                    </div>
                </div>
            )}

            {showColorSize && (
                <div onMouseDown={(e) => { if (!e.target.closest('.color-btn, .palette-ctrl')) { setIsDraggingPalette(true); const sx = e.clientX - palettePos.x, sy = e.clientY - palettePos.y; const mm = (me) => setPalettePos({ x: me.clientX - sx, y: me.clientY - sy }); const mu = () => { setIsDraggingPalette(false); window.removeEventListener('mousemove', mm); window.removeEventListener('mouseup', mu) }; window.addEventListener('mousemove', mm); window.addEventListener('mouseup', mu) } }}
                    className={`absolute z-40 flex items-center gap-3 bg-gray-900/95 backdrop-blur-md rounded-xl px-4 py-2 border border-white/5 shadow-2xi ${paletteOrientation === 'vertical' ? 'flex-col min-w-[56px]' : 'flex-row'}`} 
                    style={{ left: palettePos.x, top: palettePos.y, transform: paletteOrientation === 'vertical' ? 'translateY(-50%)' : 'translateX(-50%)' }}>
                    <div className="cursor-grab text-gray-600"><GripVertical className="w-4 h-4" /></div>
                    
                    <button 
                        onClick={() => setPaletteOrientation(o => o === 'horizontal' ? 'vertical' : 'horizontal')}
                        className="palette-ctrl p-1.5 rounded-lg bg-white/5 text-gray-500 hover:text-white"
                        title="Toggle Orientation"
                    >
                        {paletteOrientation === 'horizontal' ? <Columns3 className="w-4 h-4" /> : <Rows3 className="w-4 h-4" />}
                    </button>

                    <div className={paletteOrientation === 'vertical' ? 'w-full h-px bg-white/10 my-1' : 'w-px h-6 bg-white/10 mx-1'} />

                    <div className={`flex gap-2 ${paletteOrientation === 'vertical' ? 'flex-col' : 'flex-row'}`}>
                        {COLORS.map(c => (
                            <button key={c} onClick={() => setColor(c)} className="color-btn w-5 h-5 rounded-full border-2" style={{ backgroundColor: c, borderColor: color === c ? '#818cf8' : 'transparent' }} />
                        ))}
                    </div>
                </div>
            )}

            <div ref={wrapRef} 
                className="flex-1 relative overflow-hidden" 
                style={{ 
                    cursor: spaceDown.current || tool === 'pan' ? 'grab' : 
                            tool === 'text' ? 'text' : 
                            tool === 'eraser' ? ERASER_CURSOR :
                            tool === 'pen' || tool === 'highlighter' ? PEN_CURSOR :
                            isShapeTool ? 'crosshair' :
                            tool === 'select' ? 'default' :
                            'crosshair',
                    touchAction: 'none' 
                }} 
                onPointerDown={onPointerDown} 
                onPointerMove={onPointerMove} 
                onPointerUp={onPointerUp}
                onDrop={onBoardDrop} 
                onDragOver={onBoardDragOver} 
                onDragEnter={onBoardDragOver}>
                <canvas ref={canvasRef} className="absolute inset-0" />
                <canvas ref={olRef} className="absolute inset-0 pointer-events-none" />
                {editingText && (
                    <textarea
                        ref={textInputRef}
                        autoFocus
                        value={editingText.text}
                        onChange={e => {
                            setEditingText(t => ({ ...t, text: e.target.value }))
                            // Auto-resize textarea height
                            e.target.style.height = 'auto'
                            e.target.style.height = e.target.scrollHeight + 'px'
                        }}
                        onBlur={finalizeText}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                                e.preventDefault()
                                finalizeText()
                            }
                            if (e.key === 'Escape') setEditingText(null)
                        }}
                        onPointerDown={e => e.stopPropagation()}
                        placeholder="Type something..."
                        className="absolute bg-gray-800/20 text-white outline-none border border-violet-500/30 rounded px-2 py-0 shadow-none z-[1000] resize-x overflow-hidden"
                        style={{
                            left: (editingText.x * cam.z + cam.x),
                            top: (editingText.y * cam.z + cam.y) + (4 * cam.z),
                            width: (editingText.w || 250) * cam.z,
                            fontSize: 18 * cam.z,
                            lineHeight: `${(18 + 4) * cam.z}px`,
                            color: editingText.color || color,
                            fontFamily: 'Inter, sans-serif',
                            fontWeight: '600',
                            textAlign: 'left'
                        }}
                    />
                )}
                {editingStickyId && (() => {
                    const s = elements.find(el => el.id === editingStickyId); if (!s) return null
                    return <textarea 
                        autoFocus 
                        value={s.text} 
                        onChange={e => setElements(els => els.map(el => el.id === s.id ? { ...el, text: e.target.value } : el))} 
                        onBlur={() => { pushHistory([...elements]); setEditingStickyId(null) }} 
                        onPointerDown={e => e.stopPropagation()}
                        className="absolute outline-none p-2 resize-none shadow-xl font-medium text-gray-900" 
                        style={{ left: s.x * cam.z + cam.x, top: s.y * cam.z + cam.y, width: s.w * cam.z, height: s.h * cam.z, backgroundColor: s.stickyColor }} 
                    />
                })()}
            </div>

            <div className="absolute bottom-4 left-4 z-20 flex bg-gray-900/80 rounded-xl px-2 py-1 border border-white/5">
                <button onClick={zoomOut} className="p-1.5 text-gray-400"><ZoomOut className="w-4 h-4" /></button>
                <button onClick={resetZoom} className="px-2 py-1 text-xs text-gray-300 min-w-[48px] text-center">{Math.round(cam.z * 100)}%</button>
                <button onClick={zoomIn} className="p-1.5 text-gray-400"><ZoomIn className="w-4 h-4" /></button>
            </div>

            <input ref={pdfInput} type="file" accept=".pdf" className="hidden" onChange={onPdfUpload} />

            {presMode && pdfPages.length > 0 && (
                <div className="fixed inset-0 z-[100] bg-black flex flex-col">
                    <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 flex bg-gray-900/80 rounded-2xl p-2 border border-white/10 shadow-2xl">
                        {['pen', 'highlighter', 'eraser'].map(t => (
                            <button key={t} onClick={() => setPresTool(t)} className={`p-2 rounded-xl ${presTool === t ? 'bg-violet-600 text-white' : 'text-gray-400'}`}>{t === 'eraser' ? <Eraser className="w-4.5 h-4.5" /> : t === 'pen' ? <Pencil className="w-4.5 h-4.5" /> : <Highlighter className="w-4.5 h-4.5" />}</button>
                        ))}
                        <div className="w-px h-6 bg-white/10 mx-2" />
                        {COLORS.slice(0, 5).map(c => <button key={c} onClick={() => setPresColor(c)} className={`w-5 h-5 rounded-full mx-1 ${presColor === c ? 'ring-2 ring-white' : ''}`} style={{ backgroundColor: c }} />)}
                        <button onClick={() => setPresMode(false)} className="ml-4 p-2 text-gray-400"><X className="w-5 h-5" /></button>
                    </div>
                    <div className="flex-1 flex items-center justify-center p-4">
                        <div className="relative">
                            <canvas ref={presCanvasRef} style={{ width: pdfPages[slideIdx].width, height: pdfPages[slideIdx].height, touchAction: 'none' }} className="bg-white shadow-2xl" onPointerDown={onPresPointerDown} onPointerMove={onPresPointerMove} onPointerUp={onPresPointerUp} />
                            <button onClick={() => setSlideIdx(i => Math.max(0, i - 1))} className="absolute top-1/2 -left-16 p-4 text-white hover:bg-white/10 rounded-full"><ChevronLeft className="w-8 h-8" /></button>
                            <button onClick={() => setSlideIdx(i => Math.min(pdfPages.length - 1, i + 1))} className="absolute top-1/2 -right-16 p-4 text-white hover:bg-white/10 rounded-full"><ChevronRight className="w-8 h-8" /></button>
                        </div>
                    </div>
                    <div className="h-12 flex items-center justify-center text-gray-500 text-xs">Slide {slideIdx + 1} / {pdfPages.length}</div>
                </div>
            )}
        </div>
    )
}
