import { Link } from 'react-router-dom'
import {
    Pencil, FileText, Download, Save, Monitor, Sparkles,
    ArrowRight, Github, Twitter, Linkedin, ChevronRight,
    Circle, Square, Type, Users
} from 'lucide-react'

export default function Home() {
    return (
        <div className="min-h-screen bg-[#030712] text-white selection:bg-violet-500/30 selection:text-violet-200">
            {/* ── Background Effects ── */}
            <div className="fixed inset-0 overflow-hidden pointer-events-none -z-10">
                <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-violet-600/10 rounded-full blur-[120px] animate-pulse-glow" />
                <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-600/10 rounded-full blur-[120px] animate-pulse-glow" style={{ animationDelay: '2s' }} />
            </div>

            {/* ── Header ── */}
            <header className="fixed top-0 left-0 right-0 z-50 glass">
                <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
                    <div className="flex items-center gap-2 group cursor-pointer">
                        <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-violet-500/20 group-hover:rotate-12 transition-transform duration-300">
                            <Pencil className="w-5 h-5 text-white" />
                        </div>
                        <span className="text-xl font-bold tracking-tight">Penta <span className="text-violet-500">Whiteboard</span></span>
                    </div>

                    <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-400">
                        <a href="#features" className="hover:text-white transition-colors">Features</a>
                        <a href="#about" className="hover:text-white transition-colors">About</a>
                        <a href="#testimonials" className="hover:text-white transition-colors">Testimonials</a>
                    </nav>

                    <div className="flex items-center gap-4">
                        <button className="hidden sm:block text-sm font-semibold text-gray-300 hover:text-white transition-colors">Login</button>
                        <Link to="/dashboard" className="bg-white text-black text-sm font-bold px-6 py-2.5 rounded-full hover:bg-gray-200 transition-all shadow-xl shadow-white/5 active:scale-95">
                            Get Started
                        </Link>
                    </div>
                </div>
            </header>

            <main className="pt-20">
                {/* ── Hero Section ── */}
                <section className="relative px-6 py-24 lg:py-36 overflow-hidden">
                    <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
                        <div className="text-left space-y-8 animate-reveal">
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-400 text-xs font-bold uppercase tracking-widest">
                                <Sparkles className="w-3 h-3" /> New: AI Icon Generation
                            </div>
                            <h1 className="text-6xl lg:text-8xl font-black tracking-tight leading-[1.1]">
                                Illustrate <br />
                                <span className="bg-gradient-to-r from-violet-400 via-indigo-400 to-cyan-400 bg-clip-text text-transparent">Your Ideas</span>
                            </h1>
                            <p className="text-gray-400 text-xl max-w-lg leading-relaxed">
                                A powerful digital whiteboard designed for learning, teaching, and idea creation. Unlimited space for your biggest thoughts.
                            </p>
                            <div className="flex flex-col sm:flex-row items-center gap-4 pt-4">
                                <Link to="/dashboard" className="group w-full sm:w-auto bg-gradient-to-r from-violet-600 to-indigo-600 px-8 py-4 rounded-full text-lg font-bold flex items-center justify-center gap-2 hover:shadow-2xl hover:shadow-violet-600/40 transition-all active:scale-95">
                                    Start Drawing <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                                </Link>
                                <button className="w-full sm:w-auto px-8 py-4 rounded-full text-gray-400 font-semibold hover:text-white hover:bg-white/5 transition-all">
                                    Watch Demo
                                </button>
                            </div>
                        </div>

                        {/* Interactive 3D Whiteboard Component */}
                        <div className="relative perspective-1000 animate-reveal" style={{ animationDelay: '0.2s' }}>
                            <div className="relative w-full aspect-[4/3] glass rounded-2xl border border-white/10 shadow-3xl animate-rotate-3d overflow-hidden flex items-center justify-center">
                                {/* Grid Background */}
                                <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '30px 30px' }} />

                                {/* Floating Drawing Elements */}
                                <div className="relative w-full h-full p-12">
                                    <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-indigo-500/20 rounded-2xl border-2 border-indigo-500/40 animate-float flex items-center justify-center backdrop-blur-md" style={{ animationDelay: '0s' }}>
                                        <Square className="w-12 h-12 text-indigo-400" />
                                    </div>
                                    <div className="absolute top-1/2 right-1/4 w-24 h-24 bg-violet-500/20 rounded-full border-2 border-violet-500/40 animate-float flex items-center justify-center backdrop-blur-md" style={{ animationDelay: '1s' }}>
                                        <Circle className="w-10 h-10 text-violet-400" />
                                    </div>
                                    <div className="absolute bottom-1/4 left-1/3 p-4 bg-emerald-500/20 rounded-lg border-2 border-emerald-500/40 animate-float flex items-center gap-3 backdrop-blur-md" style={{ animationDelay: '2s' }}>
                                        <Type className="w-6 h-6 text-emerald-400" />
                                        <span className="text-emerald-400 font-mono text-sm">Design Pipeline</span>
                                    </div>

                                    {/* Cursor trail simulation */}
                                    <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-40">
                                        <path d="M100,100 C150,200 300,50 400,250" fill="none" stroke="#818cf8" strokeWidth="4" strokeDasharray="1000" strokeDashoffset="0" />
                                    </svg>
                                </div>
                            </div>
                            {/* Glow behind 3D object */}
                            <div className="absolute -inset-4 bg-violet-500/20 blur-3xl -z-10 rounded-full animate-pulse" />
                        </div>
                    </div>
                </section>

                {/* ── Features Section ── */}
                <section id="features" className="py-24 px-6 bg-gray-950/50">
                    <div className="max-w-7xl mx-auto space-y-16">
                        <div className="text-center space-y-4">
                            <h2 className="text-4xl lg:text-5xl font-bold tracking-tight">Supercharged for <span className="text-violet-500">Education</span></h2>
                            <p className="text-gray-400 text-lg max-w-2xl mx-auto">Everything you need to visualize complex ideas and teach with clarity.</p>
                        </div>

                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                            {[
                                {
                                    title: "Digital Whiteboard",
                                    desc: "Write and draw freely on an infinite whiteboard for notes, teaching, and brainstorming.",
                                    icon: Pencil,
                                    color: "from-blue-500 to-indigo-500"
                                },
                                {
                                    title: "Open and Teach with PDF",
                                    desc: "Import PDF files and write directly on them while teaching or explaining concepts.",
                                    icon: FileText,
                                    color: "from-red-500 to-orange-500"
                                },
                                {
                                    title: "Export Notes as PDF",
                                    desc: "Export your whiteboard notes easily as a PDF for sharing or saving with high fidelity.",
                                    icon: Download,
                                    color: "from-emerald-500 to-teal-500"
                                },
                                {
                                    title: "Save and Continue",
                                    desc: "Save your whiteboard files so you can reopen them later and continue editing naturally.",
                                    icon: Save,
                                    color: "from-amber-500 to-orange-500"
                                },
                                {
                                    title: "Desktop Application",
                                    desc: "Available as a native desktop application for Windows and Linux for pro performance.",
                                    icon: Monitor,
                                    color: "from-violet-500 to-purple-500"
                                },
                                {
                                    title: "AI SVG Generator",
                                    desc: "Built-in AI feature that can generate professional SVG graphics and icons instantly.",
                                    icon: Sparkles,
                                    color: "from-pink-500 to-rose-500"
                                }
                            ].map((f, i) => (
                                <div key={i} className="group glass p-8 rounded-3xl hover:bg-white/[0.05] transition-all border-white/5 hover:border-white/10 glass-hover">
                                    <div className={`w-14 h-14 bg-gradient-to-br ${f.color} rounded-2xl flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 transition-transform`}>
                                        <f.icon className="w-7 h-7 text-white" />
                                    </div>
                                    <h3 className="text-xl font-bold mb-3">{f.title}</h3>
                                    <p className="text-gray-400 leading-relaxed text-sm">{f.desc}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>

                {/* ── Testimonials ── */}
                <section id="testimonials" className="py-24 px-6 overflow-hidden relative">
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-violet-600/5 blur-[150px] -z-10" />
                    <div className="max-w-4xl mx-auto text-center space-y-12 animate-reveal">
                        <Users className="w-12 h-12 text-violet-500 mx-auto opacity-50" />
                        <blockquote className="text-3xl lg:text-4xl font-medium leading-tight">
                            "Penta Whiteboard was created to make teaching, learning, and idea sharing easier. I wanted a tool where anyone could write freely, explain concepts visually, and organize knowledge in a simple but powerful way."
                        </blockquote>
                        <div className="flex flex-col items-center gap-1">
                            <span className="text-lg font-bold text-white">Yagyadeep Ahirwar</span>
                            <span className="text-sm text-violet-400 font-semibold tracking-wider uppercase">Creator of Penta Whiteboard</span>
                        </div>
                    </div>
                </section>

                {/* ── CTA Section ── */}
                <section className="py-24 px-6">
                    <div className="max-w-7xl mx-auto relative overflow-hidden bg-gradient-to-br from-violet-600 to-indigo-800 rounded-[3rem] p-12 lg:p-24 text-center space-y-8 shadow-3xl">
                        {/* Decorative Background Circles */}
                        <div className="absolute -top-24 -left-24 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
                        <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-violet-900/40 rounded-full blur-3xl" />

                        <h2 className="text-4xl lg:text-6xl font-black tracking-tight leading-tight">Ready to bring your <br /> ideas to life?</h2>
                        <p className="text-white/80 text-xl max-w-2xl mx-auto leading-relaxed">
                            Join thousands of educators and creators who are visualizing the future with Penta Whiteboard.
                        </p>
                        <div className="pt-8">
                            <Link to="/dashboard" className="bg-white text-black px-12 py-5 rounded-full text-xl font-black hover:bg-gray-100 transition-all shadow-2xl hover:scale-105 active:scale-95 flex items-center gap-3 mx-auto w-fit">
                                Get Started Now <ChevronRight className="w-6 h-6" />
                            </Link>
                        </div>
                    </div>
                </section>
            </main>

            {/* ── Footer ── */}
            <footer className="py-16 px-6 border-t border-white/5 bg-gray-950/80 backdrop-blur-md">
                <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 text-sm">
                    <div className="col-span-2 space-y-6">
                        <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center">
                                <Pencil className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-lg font-bold">Penta</span>
                        </div>
                        <p className="text-gray-500 max-w-sm">
                            The next generation of digital teaching tools. Designed with passion for creators, by creators.
                        </p>
                        <div className="flex items-center gap-6">
                            <Twitter className="w-5 h-5 text-gray-500 hover:text-sky-400 cursor-pointer transition-colors" />
                            <Github className="w-5 h-5 text-gray-500 hover:text-white cursor-pointer transition-colors" />
                            <Linkedin className="w-5 h-5 text-gray-500 hover:text-blue-500 cursor-pointer transition-colors" />
                        </div>
                    </div>

                    <div className="space-y-6">
                        <h4 className="font-bold text-white">Product</h4>
                        <ul className="space-y-4 text-gray-500">
                            <li><Link to="/dashboard" className="hover:text-violet-400 transition-colors">Launch App</Link></li>
                            <li className="hover:text-violet-400 cursor-pointer">Desktop App</li>
                            <li className="hover:text-violet-400 cursor-pointer">AI Generator</li>
                            <li className="hover:text-violet-400 cursor-pointer">Changelog</li>
                        </ul>
                    </div>

                    <div className="space-y-6">
                        <h4 className="font-bold text-white">Legal</h4>
                        <ul className="space-y-4 text-gray-500">
                            <li className="hover:text-violet-400 cursor-pointer">Privacy Policy</li>
                            <li className="hover:text-violet-400 cursor-pointer">Terms of Service</li>
                            <li className="hover:text-violet-400 cursor-pointer">License</li>
                        </ul>
                    </div>
                </div>

                <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-6 text-gray-500 text-xs">
                    <p>© 2024 Penta Whiteboard. All rights reserved.</p>
                    <p className="flex items-center gap-1.5 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all cursor-default">
                        Built with 💜 by <span className="text-white font-bold">Yagyadeep Ahirwar</span>
                    </p>
                </div>
            </footer>
        </div>
    )
}
