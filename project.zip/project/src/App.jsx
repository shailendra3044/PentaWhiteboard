import { HashRouter, Routes, Route, Navigate } from 'react-router-dom'
import { ClerkProvider, SignedIn, SignedOut, RedirectToSignIn } from '@clerk/clerk-react'

import Home from './pages/Home'
import Board from './pages/Board'
import PdfBoard from './pages/PdfBoard'
import Dashboard from './pages/Dashboard'
import LoginPage from './pages/Login'
import RegisterPage from './pages/Register'

const CLERK_PUBLISHABLE_KEY = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY

if (!CLERK_PUBLISHABLE_KEY) {
    throw new Error("Missing Clerk Publishable Key")
}

export default function App() {
    return (
        <ClerkProvider publishableKey={CLERK_PUBLISHABLE_KEY}>
            <HashRouter>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/register" element={<RegisterPage />} />

                    {/* Protected Routes */}
                    <Route path="/dashboard" element={
                        <>
                            <SignedIn>
                                <Dashboard />
                            </SignedIn>
                            <SignedOut>
                                <RedirectToSignIn />
                            </SignedOut>
                        </>
                    } />

                    <Route path="/board/:id" element={
                        <>
                            <SignedIn>
                                <Board />
                            </SignedIn>
                            <SignedOut>
                                <RedirectToSignIn />
                            </SignedOut>
                        </>
                    } />

                    <Route path="/pdf-board/:id" element={
                        <>
                            <SignedIn>
                                <PdfBoard />
                            </SignedIn>
                            <SignedOut>
                                <RedirectToSignIn />
                            </SignedOut>
                        </>
                    } />

                    {/* Fallback */}
                    <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
            </HashRouter>
        </ClerkProvider>
    )
}
